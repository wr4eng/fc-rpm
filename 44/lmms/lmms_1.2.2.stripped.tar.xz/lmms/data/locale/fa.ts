<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>AboutDialog</name>
    <message>
        <source>About LMMS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Version %1 (%2/%3, Qt %4, %5)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>About</source>
        <translation type="unfinished">درباره</translation>
    </message>
    <message>
        <source>LMMS - easy music production for everyone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Authors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Translation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current language not translated (or native English).

If you&apos;re interested in translating LMMS in another language or want to improve existing translations, you&apos;re welcome to help us! Simply contact the maintainer!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>License</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copyright (c) 2004-2014, LMMS developers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;http://lmms.io&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;http://lmms.io&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LMMS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Involved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Contributors ordered by number of commits:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AmplifierControlDialog</name>
    <message>
        <source>VOL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volume:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PAN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Panning:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LEFT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Left gain:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>RIGHT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Right gain:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AmplifierControls</name>
    <message>
        <source>Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Panning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Left gain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Right gain</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AudioAlsa::setupWidget</name>
    <message>
        <source>DEVICE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CHANNELS</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AudioFileProcessorView</name>
    <message>
        <source>Open other sample</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here, if you want to open another audio-file. A dialog will appear where you can select your file. Settings like looping-mode, start and end-points, amplify-value, and so on are not reset. So, it may not sound like the original sample.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reverse sample</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If you enable this button, the whole sample is reversed. This is useful for cool effects, e.g. a reversed crash.</source>
        <translation type="unfinished">اگر این دکمه را فعال کنید,تمام نمونه معکوس می شود.این برای جلوه های جالب مانند یک تصادف معکوس مناسب است.</translation>
    </message>
    <message>
        <source>Amplify:</source>
        <translation type="unfinished">تقویت:</translation>
    </message>
    <message>
        <source>With this knob you can set the amplify ratio. When you set a value of 100% your sample isn&apos;t changed. Otherwise it will be amplified up or down (your actual sample-file isn&apos;t touched!)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Startpoint:</source>
        <translation type="unfinished">نقطه ی شروع:</translation>
    </message>
    <message>
        <source>Endpoint:</source>
        <translation type="unfinished">نقطه ی پایان:</translation>
    </message>
    <message>
        <source>Continue sample playback across notes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enabling this option makes the sample continue playing across different notes - if you change pitch, or the note length stops before the end of the sample, then the next note played will continue where it left off. To reset the playback to the start of the sample, insert a note at the bottom of the keyboard (&lt; 20 Hz)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Disable loop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This button disables looping. The sample plays only once from start to end. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable loop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This button enables forwards-looping. The sample loops between the end point and the loop point.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This button enables ping-pong-looping. The sample loops backwards and forwards between the end point and the loop point.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>With this knob you can set the point where AudioFileProcessor should begin playing your sample. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>With this knob you can set the point where AudioFileProcessor should stop playing your sample. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Loopback point:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>With this knob you can set the point where the loop starts. </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AudioFileProcessorWaveView</name>
    <message>
        <source>Sample length:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AudioJack</name>
    <message>
        <source>JACK client restarted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LMMS was kicked by JACK for some reason. Therefore the JACK backend of LMMS has been restarted. You will have to make manual connections again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>JACK server down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The JACK server seems to have been shutdown and starting a new instance failed. Therefore LMMS is unable to proceed. You should save your project and restart JACK and LMMS.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CLIENT-NAME</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CHANNELS</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AudioOss::setupWidget</name>
    <message>
        <source>DEVICE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CHANNELS</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AudioPortAudio::setupWidget</name>
    <message>
        <source>BACKEND</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>DEVICE</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AudioPulseAudio::setupWidget</name>
    <message>
        <source>DEVICE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CHANNELS</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AudioSdl::setupWidget</name>
    <message>
        <source>DEVICE</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AutomatableModel</name>
    <message>
        <source>&amp;Reset (%1%2)</source>
        <translation type="unfinished">&amp;باز نشانی (%1%2)</translation>
    </message>
    <message>
        <source>&amp;Copy value (%1%2)</source>
        <translation type="unfinished">کپی  &amp;مقدار (%1%2)</translation>
    </message>
    <message>
        <source>&amp;Paste value (%1%2)</source>
        <translation type="unfinished">چسباندن  &amp;مقدار (%1%2)</translation>
    </message>
    <message>
        <source>Edit song-global automation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Connected to %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Connected to controller</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit connection...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove connection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Connect to controller...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove song-global automation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove all linked controls</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AutomationEditor</name>
    <message>
        <source>Please open an automation pattern with the context menu of a control!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Values copied</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All selected values were copied to the clipboard.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AutomationEditorWindow</name>
    <message>
        <source>Play/pause current pattern (Space)</source>
        <translation type="unfinished">پخش/مکث الگوی جاری (فاصله)</translation>
    </message>
    <message>
        <source>Click here if you want to play the current pattern. This is useful while editing it.  The pattern is automatically looped when the end is reached.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stop playing of current pattern (Space)</source>
        <translation type="unfinished">توقف پخش الگوی جاری (فاصله)</translation>
    </message>
    <message>
        <source>Click here if you want to stop playing of the current pattern.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Draw mode (Shift+D)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Erase mode (Shift+E)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Flip vertically</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Flip horizontally</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here and the pattern will be inverted.The points are flipped in the y direction. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here and the pattern will be reversed. The points are flipped in the x direction.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here and draw-mode will be activated. In this mode you can add and move single values.  This is the default mode which is used most of the time.  You can also press &apos;Shift+D&apos; on your keyboard to activate this mode.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here and erase-mode will be activated. In this mode you can erase single values. You can also press &apos;Shift+E&apos; on your keyboard to activate this mode.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Discrete progression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Linear progression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cubic Hermite progression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tension value for spline</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A higher tension value may make a smoother curve but overshoot some values. A low tension value will cause the slope of the curve to level off at each control point.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here to choose discrete progressions for this automation pattern.  The value of the connected object will remain constant between control points and be set immediately to the new value when each control point is reached.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here to choose linear progressions for this automation pattern.  The value of the connected object will change at a steady rate over time between control points to reach the correct value at each control point without a sudden change.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here to choose cubic hermite progressions for this automation pattern.  The value of the connected object will change in a smooth curve and ease in to the peaks and valleys.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cut selected values (%1+X)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copy selected values (%1+C)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Paste values from clipboard (%1+V)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here and selected values will be cut into the clipboard.  You can paste them anywhere in any pattern by clicking on the paste button.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here and selected values will be copied into the clipboard.  You can paste them anywhere in any pattern by clicking on the paste button.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here and the values from the clipboard will be pasted at the first visible measure.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tension: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Automation Editor - no pattern</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Automation Editor - %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AutomationPattern</name>
    <message>
        <source>Drag a control while pressing &lt;%1&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Model is already connected to this pattern.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AutomationPatternView</name>
    <message>
        <source>double-click to open this pattern in automation editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open in Automation editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset name</source>
        <translation type="unfinished">باز نشانی نام</translation>
    </message>
    <message>
        <source>Change name</source>
        <translation type="unfinished">تغییر نام</translation>
    </message>
    <message>
        <source>%1 Connections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Disconnect &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set/clear record</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Flip Vertically (Visible)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Flip Horizontally (Visible)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AutomationTrack</name>
    <message>
        <source>Automation track</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BBEditor</name>
    <message>
        <source>Beat+Bassline Editor</source>
        <translation type="unfinished">ویرایشگر خط-بم/تپش</translation>
    </message>
    <message>
        <source>Play/pause current beat/bassline (Space)</source>
        <translation type="unfinished">پخش/درنگ خط-بم/تپش جاری(فاصله)</translation>
    </message>
    <message>
        <source>Stop playback of current beat/bassline (Space)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here to play the current beat/bassline.  The beat/bassline is automatically looped when its end is reached.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here to stop playing of current beat/bassline.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add beat/bassline</source>
        <translation type="unfinished">اضافه ی خط بم/تپش (beat/baseline)</translation>
    </message>
    <message>
        <source>Add automation-track</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove steps</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add steps</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BBTCOView</name>
    <message>
        <source>Open in Beat+Bassline-Editor</source>
        <translation type="unfinished">در ویرایشگر خط-بم/تپش باز کن</translation>
    </message>
    <message>
        <source>Reset name</source>
        <translation type="unfinished">باز نشانی نام</translation>
    </message>
    <message>
        <source>Change name</source>
        <translation type="unfinished">تغییر نام</translation>
    </message>
    <message>
        <source>Change color</source>
        <translation type="unfinished">تغییر رنگ</translation>
    </message>
    <message>
        <source>Reset color to default</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BBTrack</name>
    <message>
        <source>Beat/Bassline %1</source>
        <translation type="unfinished">خط-بم/تپش %1</translation>
    </message>
    <message>
        <source>Clone of %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BassBoosterControlDialog</name>
    <message>
        <source>FREQ</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Frequency:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>GAIN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gain:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>RATIO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ratio:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BassBoosterControls</name>
    <message>
        <source>Frequency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ratio</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BitcrushControlDialog</name>
    <message>
        <source>IN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OUT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>GAIN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input Gain:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>NOIS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input Noise:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output Gain:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CLIP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output Clip:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rate Enabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable samplerate-crushing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Depth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Depth Enabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable bitdepth-crushing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sample rate:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>STD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stereo difference:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Levels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Levels:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CaptionMenu</name>
    <message>
        <source>&amp;Help</source>
        <translation type="unfinished">&amp;راهنما</translation>
    </message>
    <message>
        <source>Help (not available)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CarlaInstrumentView</name>
    <message>
        <source>Show GUI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here to show or hide the graphical user interface (GUI) of Carla.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Controller</name>
    <message>
        <source>Controller %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ControllerConnectionDialog</name>
    <message>
        <source>Connection Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MIDI CONTROLLER</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input channel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CHANNEL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input controller</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CONTROLLER</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Auto Detect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MIDI-devices to receive MIDI-events from</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>USER CONTROLLER</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MAPPING FUNCTION</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished">لغو</translation>
    </message>
    <message>
        <source>LMMS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cycle Detected.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ControllerRackView</name>
    <message>
        <source>Controller Rack</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirm Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Confirm delete? There are existing connection(s) associted with this controller. There is no way to undo.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ControllerView</name>
    <message>
        <source>Controls</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Controllers are able to automate the value of a knob, slider, and other controls.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rename controller</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter the new name for this controller</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Remove this plugin</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CrossoverEQControlDialog</name>
    <message>
        <source>Band 1/2 Crossover:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Band 2/3 Crossover:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Band 3/4 Crossover:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Band 1 Gain:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Band 2 Gain:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Band 3 Gain:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Band 4 Gain:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Band 1 Mute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mute Band 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Band 2 Mute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mute Band 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Band 3 Mute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mute Band 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Band 4 Mute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mute Band 4</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DelayControls</name>
    <message>
        <source>Delay Samples</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Feedback</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lfo Frequency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lfo Amount</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DelayControlsDialog</name>
    <message>
        <source>Delay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delay Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Regen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Feedback Amount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lfo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lfo Amt</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DetuningHelper</name>
    <message>
        <source>Note detuning</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DualFilterControlDialog</name>
    <message>
        <source>Filter 1 enabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Filter 2 enabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click to enable/disable Filter 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click to enable/disable Filter 2</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DualFilterControls</name>
    <message>
        <source>Filter 1 enabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Filter 1 type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cutoff 1 frequency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Q/Resonance 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gain 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mix</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Filter 2 enabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Filter 2 type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cutoff 2 frequency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Q/Resonance 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gain 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LowPass</source>
        <translation type="unfinished">پایین گذر</translation>
    </message>
    <message>
        <source>HiPass</source>
        <translation type="unfinished">بالا گذر</translation>
    </message>
    <message>
        <source>BandPass csg</source>
        <translation type="unfinished">میان گذر csg</translation>
    </message>
    <message>
        <source>BandPass czpg</source>
        <translation type="unfinished">میان گذر czpg</translation>
    </message>
    <message>
        <source>Notch</source>
        <translation type="unfinished">نچ</translation>
    </message>
    <message>
        <source>Allpass</source>
        <translation type="unfinished">تمام گذر</translation>
    </message>
    <message>
        <source>Moog</source>
        <translation type="unfinished">موگ Moog</translation>
    </message>
    <message>
        <source>2x LowPass</source>
        <translation type="unfinished">پایین گذر 2x</translation>
    </message>
    <message>
        <source>RC LowPass 12dB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>RC BandPass 12dB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>RC HighPass 12dB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>RC LowPass 24dB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>RC BandPass 24dB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>RC HighPass 24dB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vocal Formant Filter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>2x Moog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SV LowPass</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SV BandPass</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SV HighPass</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SV Notch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fast Formant</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tripole</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DummyEffect</name>
    <message>
        <source>NOT FOUND</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Editor</name>
    <message>
        <source>Play (Space)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stop (Space)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Record</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Record while playing</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Effect</name>
    <message>
        <source>Effect enabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wet/Dry mix</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gate</source>
        <translation type="unfinished">مدخل</translation>
    </message>
    <message>
        <source>Decay</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EffectChain</name>
    <message>
        <source>Effects enabled</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EffectRackView</name>
    <message>
        <source>EFFECTS CHAIN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add effect</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EffectSelectDialog</name>
    <message>
        <source>Add effect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Plugin description</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EffectView</name>
    <message>
        <source>Toggles the effect on or off.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>On/Off</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>W/D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wet Level:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The Wet/Dry knob sets the ratio between the input signal and the effect signal that forms the output.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>DECAY</source>
        <translation type="unfinished">DECAY</translation>
    </message>
    <message>
        <source>Time:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The Decay knob controls how many buffers of silence must pass before the plugin stops processing.  Smaller values will reduce the CPU overhead but run the risk of clipping the tail on delay and reverb effects.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>GATE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gate:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The Gate knob controls the signal level that is considered to be &apos;silence&apos; while deciding when to stop processing signals.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Controls</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Effect plugins function as a chained series of effects where the signal will be processed from top to bottom.

The On/Off switch allows you to bypass a given plugin at any point in time.

The Wet/Dry knob controls the balance between the input signal and the effected signal that is the resulting output from the effect.  The input for the stage is the output from the previous stage. So, the &apos;dry&apos; signal for effects lower in the chain contains all of the previous effects.

The Decay knob controls how long the signal will continue to be processed after the notes have been released.  The effect will stop processing signals when the volume has dropped below a given threshold for a given length of time.  This knob sets the &apos;given length of time&apos;.  Longer times will require more CPU, so this number should be set low for most effects.  It needs to be bumped up for effects that produce lengthy periods of silence, e.g. delays.

The Gate knob controls the &apos;given threshold&apos; for the effect&apos;s auto shutdown.  The clock for the &apos;given length of time&apos; will begin as soon as the processed signal level drops below the level specified with this knob.

The Controls button opens a dialog for editing the effect&apos;s parameters.

Right clicking will bring up a context menu where you can change the order in which the effects are processed or delete an effect altogether.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move &amp;up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move &amp;down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Remove this plugin</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EnvelopeAndLfoParameters</name>
    <message>
        <source>Predelay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Attack</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Decay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sustain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Release</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modulation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LFO Predelay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LFO Attack</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LFO speed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LFO Modulation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LFO Wave Shape</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Freq x 100</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modulate Env-Amount</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EnvelopeAndLfoView</name>
    <message>
        <source>DEL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Predelay:</source>
        <translation type="unfinished">پبش تاخیر(Predelay):</translation>
    </message>
    <message>
        <source>Use this knob for setting predelay of the current envelope. The bigger this value the longer the time before start of actual envelope.</source>
        <translation type="unfinished">از این دستگیره برای تنظیم پیش تاخیر پاکت جاری استفاده کنید.هرچه این مقدار بیشتر باشد زمان بیشتری قبل از شروع واقعی پاکت طول می کشد.</translation>
    </message>
    <message>
        <source>ATT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Attack:</source>
        <translation type="unfinished">تهاجم(Attack):</translation>
    </message>
    <message>
        <source>Use this knob for setting attack-time of the current envelope. The bigger this value the longer the envelope needs to increase to attack-level. Choose a small value for instruments like pianos and a big value for strings.</source>
        <translation type="unfinished">از این دستگیره برای تنظیم زمان تهاجم پاکت جاری استفاده کنید.هرچه این مقدار بیشتر باشد پاکت زمان بیشتزی برای افزایش تا سطح تهاجم نیاز دازد.مقدار کم را برای دستگاه هایی مانند پیانو و مقدار زیاد را برای زهی استفاده کنید.</translation>
    </message>
    <message>
        <source>HOLD</source>
        <translation type="unfinished">HOLD</translation>
    </message>
    <message>
        <source>Hold:</source>
        <translation type="unfinished">نگهداری(Hold):</translation>
    </message>
    <message>
        <source>Use this knob for setting hold-time of the current envelope. The bigger this value the longer the envelope holds attack-level before it begins to decrease to sustain-level.</source>
        <translation type="unfinished">از این دستگیره برای تنظیم زمان تامل پاکت جاری استفاده کنید.هرچه این مقدار بیشتر باشد بیشتر طول می کشد تا پاکت سطح تهاجم را قبل از کاهش یه سطح تقویت(sustain-level) نگهدارد.</translation>
    </message>
    <message>
        <source>DEC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Decay:</source>
        <translation type="unfinished">محو شدن(Decay):</translation>
    </message>
    <message>
        <source>Use this knob for setting decay-time of the current envelope. The bigger this value the longer the envelope needs to decrease from attack-level to sustain-level. Choose a small value for instruments like pianos.</source>
        <translation type="unfinished">از این دستگیره برای تنظیم زمان محو شدن پاکت جاری استفاده کنید. هرچه این مقدار بیشتر باشد زمان بیشتری برای کاهش از سطح تهاجم به سطح تقویت طول کشد.مقدار کمی را برای دستگاه هایی مانند پیانو انتخاب کنید.</translation>
    </message>
    <message>
        <source>SUST</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sustain:</source>
        <translation type="unfinished">تقویت(Sustain):</translation>
    </message>
    <message>
        <source>Use this knob for setting sustain-level of the current envelope. The bigger this value the higher the level on which the envelope stays before going down to zero.</source>
        <translation type="unfinished">از این دستگیره برای تنظیم سطح تقویت(Sustain Level) پاکت جاری استفاده کنید. هرچه این مقدار بیشتر باشد پاکت در سطح بالاتری قبل از نزول به صفر قرار می گیرد.</translation>
    </message>
    <message>
        <source>REL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Release:</source>
        <translation type="unfinished">رهایی(Release):</translation>
    </message>
    <message>
        <source>Use this knob for setting release-time of the current envelope. The bigger this value the longer the envelope needs to decrease from sustain-level to zero. Choose a big value for soft instruments like strings.</source>
        <translation type="unfinished">از این دستگیره برای تنظیم زمان رهایی پاکت جاری استفاده کنید. هرچه این مقدار بیشتر باشد زمان بیشتری برای کاهش از سطح تقویت به صفر طول کشد.مقدار زیاد را برای دستگاه های زهی انتخاب کنید.</translation>
    </message>
    <message>
        <source>AMT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modulation amount:</source>
        <translation type="unfinished">میزان مدولاسیون:</translation>
    </message>
    <message>
        <source>Use this knob for setting modulation amount of the current envelope. The bigger this value the more the according size (e.g. volume or cutoff-frequency) will be influenced by this envelope.</source>
        <translation type="unfinished">از این دسته برای تنظیم مقدار مذولاسیون پاکت جاری استفاده کنید.هرچه این مقدار بیشتر باشد اندازه ی منتخب بیشتری(برای مثال حجم یا فرکانس گوشه ای) تحت تاثیر این پاکت قرار می گیرد.</translation>
    </message>
    <message>
        <source>LFO predelay:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use this knob for setting predelay-time of the current LFO. The bigger this value the the time until the LFO starts to oscillate.</source>
        <translation type="unfinished">ار این دستگیره برای تنظیم زمان پیش تاخیر LFO جاری استفاده کنید.هرچه این مقدار بیشتر باشد زمان بیشتزی تا شروع نوسان LFO طول می کشد.</translation>
    </message>
    <message>
        <source>LFO- attack:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use this knob for setting attack-time of the current LFO. The bigger this value the longer the LFO needs to increase its amplitude to maximum.</source>
        <translation type="unfinished">از این دستگیره برای تنظیم زمان تهاجم LFO جاری استفاده کنید.هرچه این مقدار بیشتر باشد LFO زمان بیشتزی برای افزایش دامنه به مقدار ماکزیمم نیاز دازد.</translation>
    </message>
    <message>
        <source>SPD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LFO speed:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use this knob for setting speed of the current LFO. The bigger this value the faster the LFO oscillates and the faster will be your effect.</source>
        <translation type="unfinished">از این دستگیره برای تنظیم سرعت LFO استفاده کنید. هرچه این مقدار بیشتر باشد LFO سریع تر نوسان می کند و جلوه ی شما سریع تر خواهد بود.</translation>
    </message>
    <message>
        <source>Use this knob for setting modulation amount of the current LFO. The bigger this value the more the selected size (e.g. volume or cutoff-frequency) will be influenced by this LFO.</source>
        <translation type="unfinished">از این دسته برای تنظیم مقدار مذولاسیون LFO جاری استفاده کنید.هرچه این مقدار بیشتر باشد اندازه ی منتخب بیشتری(برای مثال حجم یا فرکانس گوشه ای) تحت تاثیر این LFO قرار می گیرد.</translation>
    </message>
    <message>
        <source>Click here for a sine-wave.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here for a triangle-wave.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here for a saw-wave for current.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here for a square-wave.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here for a user-defined wave. Afterwards, drag an according sample-file onto the LFO graph.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FREQ x 100</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here if the frequency of this LFO should be multiplied by 100.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>multiply LFO-frequency by 100</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MODULATE ENV-AMOUNT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here to make the envelope-amount controlled by this LFO.</source>
        <translation type="unfinished">برای اینکه میزان پاکت توسط این LFO کنترل شود اینجا را کلیک کنید.</translation>
    </message>
    <message>
        <source>control envelope-amount by this LFO</source>
        <translation type="unfinished">کنترل مقدار پاکت توسط این LFO</translation>
    </message>
    <message>
        <source>ms/LFO:</source>
        <translation type="unfinished">ms/LFO:</translation>
    </message>
    <message>
        <source>Hint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Drag a sample from somewhere and drop it in this window.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here for random wave.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EqControls</name>
    <message>
        <source>Input gain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output gain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Low shelf gain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Peak 1 gain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Peak 2 gain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Peak 3 gain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Peak 4 gain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>High Shelf gain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>HP res</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Low Shelf res</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Peak 1 BW</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Peak 2 BW</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Peak 3 BW</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Peak 4 BW</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>High Shelf res</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LP res</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>HP freq</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Low Shelf freq</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Peak 1 freq</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Peak 2 freq</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Peak 3 freq</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Peak 4 freq</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>High shelf freq</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LP freq</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>HP active</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Low shelf active</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Peak 1 active</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Peak 2 active</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Peak 3 active</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Peak 4 active</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>High shelf active</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LP active</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LP 12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LP 24</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LP 48</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>HP 12</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>HP 24</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>HP 48</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>low pass type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>high pass type</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EqControlsDialog</name>
    <message>
        <source>HP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Low Shelf</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Peak 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Peak 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Peak 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Peak 4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>High Shelf</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>In Gain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Out Gain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bandwidth: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Resonance : </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Frequency:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>12dB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>24dB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>48dB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>lp grp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>hp grp</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EqParameterWidget</name>
    <message>
        <source>Hz </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ExportProjectDialog</name>
    <message>
        <source>Export project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File format:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Samplerate:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>44100 Hz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>48000 Hz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>88200 Hz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>96000 Hz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>192000 Hz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bitrate:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>64 KBit/s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>128 KBit/s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>160 KBit/s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>192 KBit/s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>256 KBit/s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>320 KBit/s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Depth:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>16 Bit Integer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>32 Bit Float</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please note that not all of the parameters above apply for all file formats.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quality settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Interpolation:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Zero Order Hold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sinc Fastest</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sinc Medium (recommended)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sinc Best (very slow!)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Oversampling (use with care!):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1x (None)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>2x</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>4x</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>8x</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished">لغو</translation>
    </message>
    <message>
        <source>Export as loop (remove end silence)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Export between loop markers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not open file</source>
        <translation type="unfinished">پرونده باز نشد</translation>
    </message>
    <message>
        <source>Could not open file %1 for writing.
Please make sure you have write-permission to the file and the directory containing the file and try again!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Export project to %1</source>
        <translation type="unfinished">استخراج پرونده به %1</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error while determining file-encoder device. Please try to choose a different output format.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rendering: %1%</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Fader</name>
    <message>
        <source>Please enter a new value between %1 and %2:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FileBrowser</name>
    <message>
        <source>Browser</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FileBrowserTreeWidget</name>
    <message>
        <source>Send to active instrument-track</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open in new instrument-track/Song-Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open in new instrument-track/B+B Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Loading sample</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please wait, loading sample for preview...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>--- Factory files ---</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FlangerControls</name>
    <message>
        <source>Delay Samples</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lfo Frequency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Regen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Noise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invert</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FlangerControlsDialog</name>
    <message>
        <source>Delay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delay Time:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lfo Hz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lfo:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Amt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Amt:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Regen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Feedback Amount:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Noise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>White Noise Amount:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FxLine</name>
    <message>
        <source>Channel send amount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The FX channel receives input from one or more instrument tracks.
 It in turn can be routed to multiple other FX channels. LMMS automatically takes care of preventing infinite loops for you and doesn&apos;t allow making a connection that would result in an infinite loop.

In order to route the channel to another channel, select the FX channel and click on the &quot;send&quot; button on the channel you want to send to. The knob under the send button controls the level of signal that is sent to the channel.

You can remove and move FX channels in the context menu, which is accessed by right-clicking the FX channel.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move &amp;left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move &amp;right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rename &amp;channel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>R&amp;emove channel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove &amp;unused channels</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FxMixer</name>
    <message>
        <source>Master</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FX %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FxMixerView</name>
    <message>
        <source>Rename FX channel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter the new name for this FX channel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FX-Mixer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FX Fader %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mute this FX channel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Solo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Solo FX channel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FxRoute</name>
    <message>
        <source>Amount to send from channel %1 to channel %2</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GigInstrument</name>
    <message>
        <source>Bank</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Patch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gain</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GigInstrumentView</name>
    <message>
        <source>Open other GIG file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here to open another GIG file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose the patch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here to change which patch of the GIG file to use</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change which instrument of the GIG file is being played</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Which GIG file is currently being used</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Which patch of the GIG file is currently being used</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Factor to multiply samples by</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open GIG file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>GIG Files (*.gig)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InstrumentFunctionArpeggio</name>
    <message>
        <source>Arpeggio</source>
        <translation type="unfinished">آرپگیو(Arpeggio)</translation>
    </message>
    <message>
        <source>Arpeggio type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Arpeggio range</source>
        <translation type="unfinished">محدوده ی آرپگیو</translation>
    </message>
    <message>
        <source>Arpeggio time</source>
        <translation type="unfinished">زمان أرپگیو</translation>
    </message>
    <message>
        <source>Arpeggio gate</source>
        <translation type="unfinished">مدخل أرپگیو</translation>
    </message>
    <message>
        <source>Arpeggio direction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Arpeggio mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Up and down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Random</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Free</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sort</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sync</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Down and up</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InstrumentFunctionArpeggioView</name>
    <message>
        <source>ARPEGGIO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>An arpeggio is a method playing (especially plucked) instruments, which makes the music much livelier. The strings of such instruments (e.g. harps) are plucked like chords. The only difference is that this is done in a sequential order, so the notes are not played at the same time. Typical arpeggios are major or minor triads, but there are a lot of other possible chords, you can select.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>RANGE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Arpeggio range:</source>
        <translation type="unfinished">محدوده ی أرپگیو:</translation>
    </message>
    <message>
        <source>octave(s)</source>
        <translation type="unfinished">نت (ها)</translation>
    </message>
    <message>
        <source>Use this knob for setting the arpeggio range in octaves. The selected arpeggio will be played within specified number of octaves.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>TIME</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Arpeggio time:</source>
        <translation type="unfinished">زمان آرپگیو:</translation>
    </message>
    <message>
        <source>ms</source>
        <translation type="unfinished">م ث</translation>
    </message>
    <message>
        <source>Use this knob for setting the arpeggio time in milliseconds. The arpeggio time specifies how long each arpeggio-tone should be played.</source>
        <translation type="unfinished">از این دستگیره برای تنظیم زمان در آرپگیو به میلی ثانیه استفاده کنید.زمان آرپگیو مشخص می کند که چه مدت هر آهنگ آرپگیو پخش شود.</translation>
    </message>
    <message>
        <source>GATE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Arpeggio gate:</source>
        <translation type="unfinished">مدخل آرپگیو:</translation>
    </message>
    <message>
        <source>%</source>
        <translation type="unfinished">%</translation>
    </message>
    <message>
        <source>Use this knob for setting the arpeggio gate. The arpeggio gate specifies the percent of a whole arpeggio-tone that should be played. With this you can make cool staccato arpeggios.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Chord:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Direction:</source>
        <translation type="unfinished">جهت:</translation>
    </message>
    <message>
        <source>Mode:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InstrumentFunctionNoteStacking</name>
    <message>
        <source>octave</source>
        <translation type="unfinished">نت</translation>
    </message>
    <message>
        <source>Major</source>
        <translation type="unfinished">Major</translation>
    </message>
    <message>
        <source>Majb5</source>
        <translation type="unfinished">Majb5</translation>
    </message>
    <message>
        <source>minor</source>
        <translation type="unfinished">minor</translation>
    </message>
    <message>
        <source>minb5</source>
        <translation type="unfinished">mollb5</translation>
    </message>
    <message>
        <source>sus2</source>
        <translation type="unfinished">sus2</translation>
    </message>
    <message>
        <source>sus4</source>
        <translation type="unfinished">sus4</translation>
    </message>
    <message>
        <source>aug</source>
        <translation type="unfinished">aug</translation>
    </message>
    <message>
        <source>augsus4</source>
        <translation type="unfinished">augsus4</translation>
    </message>
    <message>
        <source>tri</source>
        <translation type="unfinished">tri</translation>
    </message>
    <message>
        <source>6</source>
        <translation type="unfinished">6</translation>
    </message>
    <message>
        <source>6sus4</source>
        <translation type="unfinished">6sus4</translation>
    </message>
    <message>
        <source>6add9</source>
        <translation type="unfinished">madd9</translation>
    </message>
    <message>
        <source>m6</source>
        <translation type="unfinished">m6</translation>
    </message>
    <message>
        <source>m6add9</source>
        <translation type="unfinished">m6add9</translation>
    </message>
    <message>
        <source>7</source>
        <translation type="unfinished">7</translation>
    </message>
    <message>
        <source>7sus4</source>
        <translation type="unfinished">7sus4</translation>
    </message>
    <message>
        <source>7#5</source>
        <translation type="unfinished">7#5</translation>
    </message>
    <message>
        <source>7b5</source>
        <translation type="unfinished">7b5</translation>
    </message>
    <message>
        <source>7#9</source>
        <translation type="unfinished">7#9</translation>
    </message>
    <message>
        <source>7b9</source>
        <translation type="unfinished">7b9</translation>
    </message>
    <message>
        <source>7#5#9</source>
        <translation type="unfinished">7#5#9</translation>
    </message>
    <message>
        <source>7#5b9</source>
        <translation type="unfinished">7#5b9</translation>
    </message>
    <message>
        <source>7b5b9</source>
        <translation type="unfinished">7b5b9</translation>
    </message>
    <message>
        <source>7add11</source>
        <translation type="unfinished">7add11</translation>
    </message>
    <message>
        <source>7add13</source>
        <translation type="unfinished">7add13</translation>
    </message>
    <message>
        <source>7#11</source>
        <translation type="unfinished">7#11</translation>
    </message>
    <message>
        <source>Maj7</source>
        <translation type="unfinished">Maj7</translation>
    </message>
    <message>
        <source>Maj7b5</source>
        <translation type="unfinished">Maj7b5</translation>
    </message>
    <message>
        <source>Maj7#5</source>
        <translation type="unfinished">Maj7#5</translation>
    </message>
    <message>
        <source>Maj7#11</source>
        <translation type="unfinished">Maj7#11</translation>
    </message>
    <message>
        <source>Maj7add13</source>
        <translation type="unfinished">Maj7add13</translation>
    </message>
    <message>
        <source>m7</source>
        <translation type="unfinished">m7</translation>
    </message>
    <message>
        <source>m7b5</source>
        <translation type="unfinished">m7b5</translation>
    </message>
    <message>
        <source>m7b9</source>
        <translation type="unfinished">m7b9</translation>
    </message>
    <message>
        <source>m7add11</source>
        <translation type="unfinished">m7add11</translation>
    </message>
    <message>
        <source>m7add13</source>
        <translation type="unfinished">m7add13</translation>
    </message>
    <message>
        <source>m-Maj7</source>
        <translation type="unfinished">m-Maj7</translation>
    </message>
    <message>
        <source>m-Maj7add11</source>
        <translation type="unfinished">m-Maj7add11</translation>
    </message>
    <message>
        <source>m-Maj7add13</source>
        <translation type="unfinished">m-Maj7add13</translation>
    </message>
    <message>
        <source>9</source>
        <translation type="unfinished">9</translation>
    </message>
    <message>
        <source>9sus4</source>
        <translation type="unfinished">9sus4</translation>
    </message>
    <message>
        <source>add9</source>
        <translation type="unfinished">add9</translation>
    </message>
    <message>
        <source>9#5</source>
        <translation type="unfinished">9#5</translation>
    </message>
    <message>
        <source>9b5</source>
        <translation type="unfinished">9b5</translation>
    </message>
    <message>
        <source>9#11</source>
        <translation type="unfinished">9#11</translation>
    </message>
    <message>
        <source>9b13</source>
        <translation type="unfinished">9b13</translation>
    </message>
    <message>
        <source>Maj9</source>
        <translation type="unfinished">Maj9</translation>
    </message>
    <message>
        <source>Maj9sus4</source>
        <translation type="unfinished">Maj9sus4</translation>
    </message>
    <message>
        <source>Maj9#5</source>
        <translation type="unfinished">Maj9#5</translation>
    </message>
    <message>
        <source>Maj9#11</source>
        <translation type="unfinished">Maj9#11</translation>
    </message>
    <message>
        <source>m9</source>
        <translation type="unfinished">m9</translation>
    </message>
    <message>
        <source>madd9</source>
        <translation type="unfinished">madd9</translation>
    </message>
    <message>
        <source>m9b5</source>
        <translation type="unfinished">m9b5</translation>
    </message>
    <message>
        <source>m9-Maj7</source>
        <translation type="unfinished">m9-Maj7</translation>
    </message>
    <message>
        <source>11</source>
        <translation type="unfinished">11</translation>
    </message>
    <message>
        <source>11b9</source>
        <translation type="unfinished">11b9</translation>
    </message>
    <message>
        <source>Maj11</source>
        <translation type="unfinished">Maj11</translation>
    </message>
    <message>
        <source>m11</source>
        <translation type="unfinished">m11</translation>
    </message>
    <message>
        <source>m-Maj11</source>
        <translation type="unfinished">m-Maj11</translation>
    </message>
    <message>
        <source>13</source>
        <translation type="unfinished">13</translation>
    </message>
    <message>
        <source>13#9</source>
        <translation type="unfinished">13#9</translation>
    </message>
    <message>
        <source>13b9</source>
        <translation type="unfinished">13b9</translation>
    </message>
    <message>
        <source>13b5b9</source>
        <translation type="unfinished">13b5b9</translation>
    </message>
    <message>
        <source>Maj13</source>
        <translation type="unfinished">Maj13</translation>
    </message>
    <message>
        <source>m13</source>
        <translation type="unfinished">m13</translation>
    </message>
    <message>
        <source>m-Maj13</source>
        <translation type="unfinished">m-Maj13</translation>
    </message>
    <message>
        <source>Harmonic minor</source>
        <translation type="unfinished">Harmonic minor</translation>
    </message>
    <message>
        <source>Melodic minor</source>
        <translation type="unfinished">Melodic minor</translation>
    </message>
    <message>
        <source>Whole tone</source>
        <translation type="unfinished">Whole tone</translation>
    </message>
    <message>
        <source>Diminished</source>
        <translation type="unfinished">Diminished</translation>
    </message>
    <message>
        <source>Major pentatonic</source>
        <translation type="unfinished">Major pentatonic</translation>
    </message>
    <message>
        <source>Minor pentatonic</source>
        <translation type="unfinished">Minor pentatonic</translation>
    </message>
    <message>
        <source>Jap in sen</source>
        <translation type="unfinished">Jap in sen</translation>
    </message>
    <message>
        <source>Major bebop</source>
        <translation type="unfinished">Major bebop</translation>
    </message>
    <message>
        <source>Dominant bebop</source>
        <translation type="unfinished">Dominant bebop</translation>
    </message>
    <message>
        <source>Blues</source>
        <translation type="unfinished">Blues</translation>
    </message>
    <message>
        <source>Arabic</source>
        <translation type="unfinished">Arabic</translation>
    </message>
    <message>
        <source>Enigmatic</source>
        <translation type="unfinished">Enigmatic</translation>
    </message>
    <message>
        <source>Neopolitan</source>
        <translation type="unfinished">Neopolitan</translation>
    </message>
    <message>
        <source>Neopolitan minor</source>
        <translation type="unfinished">Neopolitan minor</translation>
    </message>
    <message>
        <source>Hungarian minor</source>
        <translation type="unfinished">Hungarian minor</translation>
    </message>
    <message>
        <source>Dorian</source>
        <translation type="unfinished">Dorian</translation>
    </message>
    <message>
        <source>Phrygolydian</source>
        <translation type="unfinished">Phrygolydian</translation>
    </message>
    <message>
        <source>Lydian</source>
        <translation type="unfinished">Lydian</translation>
    </message>
    <message>
        <source>Mixolydian</source>
        <translation type="unfinished">Mixolydian</translation>
    </message>
    <message>
        <source>Aeolian</source>
        <translation type="unfinished">Aeolian</translation>
    </message>
    <message>
        <source>Locrian</source>
        <translation type="unfinished">Locrian</translation>
    </message>
    <message>
        <source>Chords</source>
        <translation type="unfinished">تار ها(Chords)</translation>
    </message>
    <message>
        <source>Chord type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Chord range</source>
        <translation type="unfinished">محدوده ی تار</translation>
    </message>
    <message>
        <source>Minor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Chromatic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Half-Whole Diminished</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>5</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InstrumentFunctionNoteStackingView</name>
    <message>
        <source>RANGE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Chord range:</source>
        <translation type="unfinished">محدوده ی تار ها :</translation>
    </message>
    <message>
        <source>octave(s)</source>
        <translation type="unfinished">نت (ها)</translation>
    </message>
    <message>
        <source>Use this knob for setting the chord range in octaves. The selected chord will be played within specified number of octaves.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>STACKING</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Chord:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InstrumentMidiIOView</name>
    <message>
        <source>ENABLE MIDI INPUT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CHANNEL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>VELOCITY</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ENABLE MIDI OUTPUT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PROGRAM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MIDI devices to receive MIDI events from</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MIDI devices to send MIDI events to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>NOTE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CUSTOM BASE VELOCITY</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Specify the velocity normalization base for MIDI-based instruments at 100% note velocity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>BASE VELOCITY</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InstrumentMiscView</name>
    <message>
        <source>MASTER PITCH</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enables the use of Master Pitch</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InstrumentSoundShaping</name>
    <message>
        <source>VOLUME</source>
        <translation type="unfinished">حجم</translation>
    </message>
    <message>
        <source>Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CUTOFF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cutoff frequency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>RESO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Resonance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Envelopes/LFOs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Filter type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Q/Resonance</source>
        <translation type="unfinished">Q/رزونانس</translation>
    </message>
    <message>
        <source>LowPass</source>
        <translation type="unfinished">پایین گذر</translation>
    </message>
    <message>
        <source>HiPass</source>
        <translation type="unfinished">بالا گذر</translation>
    </message>
    <message>
        <source>BandPass csg</source>
        <translation type="unfinished">میان گذر csg</translation>
    </message>
    <message>
        <source>BandPass czpg</source>
        <translation type="unfinished">میان گذر czpg</translation>
    </message>
    <message>
        <source>Notch</source>
        <translation type="unfinished">نچ</translation>
    </message>
    <message>
        <source>Allpass</source>
        <translation type="unfinished">تمام گذر</translation>
    </message>
    <message>
        <source>Moog</source>
        <translation type="unfinished">موگ Moog</translation>
    </message>
    <message>
        <source>2x LowPass</source>
        <translation type="unfinished">پایین گذر 2x</translation>
    </message>
    <message>
        <source>RC LowPass 12dB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>RC BandPass 12dB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>RC HighPass 12dB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>RC LowPass 24dB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>RC BandPass 24dB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>RC HighPass 24dB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vocal Formant Filter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>2x Moog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SV LowPass</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SV BandPass</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SV HighPass</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SV Notch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fast Formant</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tripole</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InstrumentSoundShapingView</name>
    <message>
        <source>TARGET</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>These tabs contain envelopes. They&apos;re very important for modifying a sound, in that they are almost always necessary for substractive synthesis. For example if you have a volume envelope, you can set when the sound should have a specific volume. If you want to create some soft strings then your sound has to fade in and out very softly. This can be done by setting large attack and release times. It&apos;s the same for other envelope targets like panning, cutoff frequency for the used filter and so on. Just monkey around with it! You can really make cool sounds out of a saw-wave with just some envelopes...!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FILTER</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Here you can select the built-in filter you want to use for this instrument-track. Filters are very important for changing the characteristics of a sound.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hz</source>
        <translation type="unfinished">Hz</translation>
    </message>
    <message>
        <source>Use this knob for setting the cutoff frequency for the selected filter. The cutoff frequency specifies the frequency for cutting the signal by a filter. For example a lowpass-filter cuts all frequencies above the cutoff frequency. A highpass-filter cuts all frequencies below cutoff frequency, and so on...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>RESO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Resonance:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use this knob for setting Q/Resonance for the selected filter. Q/Resonance tells the filter how much it should amplify frequencies near Cutoff-frequency.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FREQ</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>cutoff frequency:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Envelopes, LFOs and filters are not supported by the current instrument.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InstrumentTrack</name>
    <message>
        <source>unnamed_track</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Panning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pitch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FX channel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default preset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>With this knob you can set the volume of the opened channel.</source>
        <translation type="unfinished">Mit diesem Knopf können Sie die Lautstärke des geöffneten Kanals ändern.</translation>
    </message>
    <message>
        <source>Base note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pitch range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Master Pitch</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InstrumentTrackView</name>
    <message>
        <source>Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volume:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>VOL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Panning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Panning:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PAN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MIDI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InstrumentTrackWindow</name>
    <message>
        <source>GENERAL SETTINGS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Instrument volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volume:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>VOL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Panning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Panning:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PAN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pitch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pitch:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>cents</source>
        <translation type="unfinished">درصد</translation>
    </message>
    <message>
        <source>PITCH</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FX channel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ENV/LFO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FUNC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FX</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MIDI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save preset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>XML preset file (*.xpf)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PLUGIN</source>
        <translation type="unfinished">اضافات</translation>
    </message>
    <message>
        <source>Pitch range (semitones)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>RANGE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save current instrument track settings in a preset file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here, if you want to save current instrument track settings in a preset file. Later you can load this preset by double-clicking it in the preset-browser.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MISC</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Knob</name>
    <message>
        <source>Set linear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set logarithmic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please enter a new value between -96.0 dBV and 6.0 dBV:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please enter a new value between %1 and %2:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LadspaControl</name>
    <message>
        <source>Link channels</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LadspaControlDialog</name>
    <message>
        <source>Link Channels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Channel </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LadspaControlView</name>
    <message>
        <source>Link channels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Value:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sorry, no help available.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LadspaEffect</name>
    <message>
        <source>Unknown LADSPA plugin %1 requested.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LcdSpinBox</name>
    <message>
        <source>Please enter a new value between %1 and %2:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LfoController</name>
    <message>
        <source>LFO Controller</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Base value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Oscillator speed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Oscillator amount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Oscillator phase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Oscillator waveform</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Frequency Multiplier</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LfoControllerDialog</name>
    <message>
        <source>LFO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LFO Controller</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>BASE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Base amount:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>todo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SPD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LFO-speed:</source>
        <translation type="unfinished">سرعت-LFO:</translation>
    </message>
    <message>
        <source>Use this knob for setting speed of the LFO. The bigger this value the faster the LFO oscillates and the faster the effect.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AMT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modulation amount:</source>
        <translation type="unfinished">میزان مدولاسیون:</translation>
    </message>
    <message>
        <source>Use this knob for setting modulation amount of the LFO. The bigger this value, the more the connected control (e.g. volume or cutoff-frequency) will be influenced by the LFO.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PHS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Phase offset:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>degrees</source>
        <translation type="unfinished">درجه ها</translation>
    </message>
    <message>
        <source>With this knob you can set the phase offset of the LFO. That means you can move the point within an oscillation where the oscillator begins to oscillate. For example if you have a sine-wave and have a phase-offset of 180 degrees the wave will first go down. It&apos;s the same with a square-wave.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here for a sine-wave.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here for a triangle-wave.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here for a saw-wave.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here for a square-wave.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here for an exponential wave.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here for white-noise.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here for a user-defined shape.
Double click to pick a file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here for a moog saw-wave.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Working directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The LMMS working directory %1 does not exist. Create it now? You can change the directory later via Edit -&gt; Settings.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not save config-file</source>
        <translation type="unfinished">پرونده ی تنظیمات ذخیره نشد</translation>
    </message>
    <message>
        <source>Could not save configuration file %1. You&apos;re probably not permitted to write to this file.
Please make sure you have write-access to the file and try again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation type="unfinished">&amp;جدید</translation>
    </message>
    <message>
        <source>&amp;Open...</source>
        <translation type="unfinished">&amp;باز کن...</translation>
    </message>
    <message>
        <source>&amp;Save</source>
        <translation type="unfinished">&amp;ذخیره کن</translation>
    </message>
    <message>
        <source>Save &amp;As...</source>
        <translation type="unfinished">ذ&amp;خیره به صورت...</translation>
    </message>
    <message>
        <source>Import...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>E&amp;xport...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation type="unfinished">&amp;خروج</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation type="unfinished">&amp;راهنما</translation>
    </message>
    <message>
        <source>Help</source>
        <translation type="unfinished">راهنما</translation>
    </message>
    <message>
        <source>What&apos;s this?</source>
        <translation type="unfinished">این چیست؟</translation>
    </message>
    <message>
        <source>About</source>
        <translation type="unfinished">درباره</translation>
    </message>
    <message>
        <source>Create new project</source>
        <translation type="unfinished">ایجاد پروژه ی جدید</translation>
    </message>
    <message>
        <source>Create new project from template</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open existing project</source>
        <translation type="unfinished">باز کردن پروژه ی موجود</translation>
    </message>
    <message>
        <source>Recently opened projects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save current project</source>
        <translation type="unfinished">ذخیره ی پروژه ی جاری</translation>
    </message>
    <message>
        <source>Export current project</source>
        <translation type="unfinished">استخراج پروژه ی جاری</translation>
    </message>
    <message>
        <source>Song Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>By pressing this button, you can show or hide the Song-Editor. With the help of the Song-Editor you can edit song-playlist and specify when which track should be played. You can also insert and move samples (e.g. rap samples) directly into the playlist.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Beat+Bassline Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>By pressing this button, you can show or hide the Beat+Bassline Editor. The Beat+Bassline Editor is needed for creating beats, and for opening, adding, and removing channels, and for cutting, copying and pasting beat and bassline-patterns, and for other things like that.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Piano Roll</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here to show or hide the Piano-Roll. With the help of the Piano-Roll you can edit melodies in an easy way.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Automation Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here to show or hide the Automation Editor. With the help of the Automation Editor you can edit dynamic values in an easy way.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FX Mixer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here to show or hide the FX Mixer. The FX Mixer is a very powerful tool for managing effects for your song. You can insert effects into different effect-channels.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Project Notes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here to show or hide the project notes window. In this window you can put down your project notes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Controller Rack</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Untitled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LMMS %1</source>
        <translation type="unfinished">LMMS %1</translation>
    </message>
    <message>
        <source>Project not saved</source>
        <translation type="unfinished">پروژه ذخیره نشده</translation>
    </message>
    <message>
        <source>The current project was modified since last saving. Do you want to save it now?</source>
        <translation type="unfinished">پروژه جاری بعد از آخرین ذخیره تغییر یافته است.آیا اکنون مایل به ذخیره ی آن هستید؟</translation>
    </message>
    <message>
        <source>Help not available</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Currently there&apos;s no help available in LMMS.
Please visit http://lmms.sf.net/wiki for documentation on LMMS.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LMMS (*.mmp *.mmpz)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Version %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Configuration file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error while parsing configuration file at line %1:%2: %3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volumes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Undo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Redo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LMMS Project </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LMMS Project Template </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>My Projects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>My Samples</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>My Presets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>My Home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>My Computer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Root Directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Recently Opened Projects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save as New &amp;Version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>E&amp;xport Tracks...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Online Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>What&apos;s This?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open Project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save Project</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MeterDialog</name>
    <message>
        <source>Meter Numerator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Meter Denominator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>TIME SIG</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MeterModel</name>
    <message>
        <source>Numerator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Denominator</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MidiAlsaRaw::setupWidget</name>
    <message>
        <source>DEVICE</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MidiAlsaSeq</name>
    <message>
        <source>DEVICE</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MidiController</name>
    <message>
        <source>MIDI Controller</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>unnamed_midi_controller</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MidiImport</name>
    <message>
        <source>Setup incomplete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You do not have set up a default soundfont in the settings dialog (Edit-&gt;Settings). Therefore no sound will be played back after importing this MIDI file. You should download a General MIDI soundfont, specify it in settings dialog and try again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You did not compile LMMS with support for SoundFont2 player, which is used to add default sound to imported MIDI files. Therefore no sound will be played back after importing this MIDI file.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MidiOss::setupWidget</name>
    <message>
        <source>DEVICE</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MidiPort</name>
    <message>
        <source>Input channel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output channel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input controller</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output controller</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fixed input velocity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fixed output velocity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output MIDI program</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Receive MIDI-events</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send MIDI-events</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fixed output note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Base velocity</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MonstroInstrument</name>
    <message>
        <source>Osc 1 Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Osc 1 Panning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Osc 1 Coarse detune</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Osc 1 Fine detune left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Osc 1 Fine detune right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Osc 1 Stereo phase offset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Osc 1 Pulse width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Osc 1 Sync send on rise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Osc 1 Sync send on fall</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Osc 2 Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Osc 2 Panning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Osc 2 Coarse detune</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Osc 2 Fine detune left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Osc 2 Fine detune right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Osc 2 Stereo phase offset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Osc 2 Waveform</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Osc 2 Sync Hard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Osc 2 Sync Reverse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Osc 3 Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Osc 3 Panning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Osc 3 Coarse detune</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Osc 3 Stereo phase offset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Osc 3 Sub-oscillator mix</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Osc 3 Waveform 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Osc 3 Waveform 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Osc 3 Sync Hard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Osc 3 Sync Reverse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LFO 1 Waveform</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LFO 1 Attack</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LFO 1 Rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LFO 1 Phase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LFO 2 Waveform</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LFO 2 Attack</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LFO 2 Rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LFO 2 Phase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Env 1 Pre-delay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Env 1 Attack</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Env 1 Hold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Env 1 Decay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Env 1 Sustain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Env 1 Release</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Env 1 Slope</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Env 2 Pre-delay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Env 2 Attack</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Env 2 Hold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Env 2 Decay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Env 2 Sustain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Env 2 Release</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Env 2 Slope</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Osc2-3 modulation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Selected view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vol1-Env1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vol1-Env2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vol1-LFO1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vol1-LFO2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vol2-Env1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vol2-Env2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vol2-LFO1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vol2-LFO2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vol3-Env1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vol3-Env2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vol3-LFO1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vol3-LFO2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Phs1-Env1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Phs1-Env2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Phs1-LFO1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Phs1-LFO2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Phs2-Env1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Phs2-Env2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Phs2-LFO1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Phs2-LFO2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Phs3-Env1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Phs3-Env2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Phs3-LFO1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Phs3-LFO2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pit1-Env1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pit1-Env2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pit1-LFO1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pit1-LFO2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pit2-Env1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pit2-Env2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pit2-LFO1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pit2-LFO2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pit3-Env1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pit3-Env2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pit3-LFO1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pit3-LFO2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PW1-Env1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PW1-Env2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PW1-LFO1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PW1-LFO2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sub3-Env1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sub3-Env2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sub3-LFO1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sub3-LFO2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sine wave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bandlimited Triangle wave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bandlimited Saw wave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bandlimited Ramp wave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bandlimited Square wave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bandlimited Moog saw wave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Soft square wave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Absolute sine wave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Exponential wave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>White noise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Digital Triangle wave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Digital Saw wave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Digital Ramp wave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Digital Square wave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Digital Moog saw wave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Triangle wave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Saw wave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ramp wave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Square wave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Moog saw wave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Abs. sine wave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Random</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Random smooth</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MonstroView</name>
    <message>
        <source>Operators view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The Operators view contains all the operators. These include both audible operators (oscillators) and inaudible operators, or modulators: Low-frequency oscillators and Envelopes. 

Knobs and other widgets in the Operators view have their own what&apos;s this -texts, so you can get more specific help for them that way. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Matrix view</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The Matrix view contains the modulation matrix. Here you can define the modulation relationships between the various operators: Each audible operator (oscillators 1-3) has 3-4 properties that can be modulated by any of the modulators. Using more modulations consumes more CPU power. 

The view is divided to modulation targets, grouped by the target oscillator. Available targets are volume, pitch, phase, pulse width and sub-osc ratio. Note: some targets are specific to one oscillator only. 

Each modulation target has 4 knobs, one for each modulator. By default the knobs are at 0, which means no modulation. Turning a knob to 1 causes that modulator to affect the modulation target as much as possible. Turning it to -1 does the same, but the modulation is inversed. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mix Osc2 with Osc3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modulate amplitude of Osc3 with Osc2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modulate frequency of Osc3 with Osc2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modulate phase of Osc3 with Osc2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The CRS knob changes the tuning of oscillator 1 in semitone steps. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The CRS knob changes the tuning of oscillator 2 in semitone steps. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The CRS knob changes the tuning of oscillator 3 in semitone steps. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FTL and FTR change the finetuning of the oscillator for left and right channels respectively. These can add stereo-detuning to the oscillator which widens the stereo image and causes an illusion of space. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The SPO knob modifies the difference in phase between left and right channels. Higher difference creates a wider stereo image. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The PW knob controls the pulse width, also known as duty cycle, of oscillator 1. Oscillator 1 is a digital pulse wave oscillator, it doesn&apos;t produce bandlimited output, which means that you can use it as an audible oscillator but it will cause aliasing. You can also use it as an inaudible source of a sync signal, which can be used to synchronize oscillators 2 and 3. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send Sync on Rise: When enabled, the Sync signal is sent every time the state of oscillator 1 changes from low to high, ie. when the amplitude changes from -1 to 1. Oscillator 1&apos;s pitch, phase and pulse width may affect the timing of syncs, but its volume has no effect on them. Sync signals are sent independently for both left and right channels. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Send Sync on Fall: When enabled, the Sync signal is sent every time the state of oscillator 1 changes from high to low, ie. when the amplitude changes from 1 to -1. Oscillator 1&apos;s pitch, phase and pulse width may affect the timing of syncs, but its volume has no effect on them. Sync signals are sent independently for both left and right channels. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hard sync: Every time the oscillator receives a sync signal from oscillator 1, its phase is reset to 0 + whatever its phase offset is. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reverse sync: Every time the oscillator receives a sync signal from oscillator 1, the amplitude of the oscillator gets inverted. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose waveform for oscillator 2. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose waveform for oscillator 3&apos;s first sub-osc. Oscillator 3 can smoothly interpolate between two different waveforms. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose waveform for oscillator 3&apos;s second sub-osc. Oscillator 3 can smoothly interpolate between two different waveforms. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The SUB knob changes the mixing ratio of the two sub-oscs of oscillator 3. Each sub-osc can be set to produce a different waveform, and oscillator 3 can smoothly interpolate between them. All incoming modulations to oscillator 3 are applied to both sub-oscs/waveforms in the exact same way. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>In addition to dedicated modulators, Monstro allows oscillator 3 to be modulated by the output of oscillator 2. 

Mix mode means no modulation: the outputs of the oscillators are simply mixed together. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>In addition to dedicated modulators, Monstro allows oscillator 3 to be modulated by the output of oscillator 2. 

AM means amplitude modulation: Oscillator 3&apos;s amplitude (volume) is modulated by oscillator 2. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>In addition to dedicated modulators, Monstro allows oscillator 3 to be modulated by the output of oscillator 2. 

FM means frequency modulation: Oscillator 3&apos;s frequency (pitch) is modulated by oscillator 2. The frequency modulation is implemented as phase modulation, which gives a more stable overall pitch than &quot;pure&quot; frequency modulation. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>In addition to dedicated modulators, Monstro allows oscillator 3 to be modulated by the output of oscillator 2. 

PM means phase modulation: Oscillator 3&apos;s phase is modulated by oscillator 2. It differs from frequency modulation in that the phase changes are not cumulative. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select the waveform for LFO 1. 
&quot;Random&quot; and &quot;Random smooth&quot; are special waveforms: they produce random output, where the rate of the LFO controls how often the state of the LFO changes. The smooth version interpolates between these states with cosine interpolation. These random modes can be used to give &quot;life&quot; to your presets - add some of that analog unpredictability... </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select the waveform for LFO 2. 
&quot;Random&quot; and &quot;Random smooth&quot; are special waveforms: they produce random output, where the rate of the LFO controls how often the state of the LFO changes. The smooth version interpolates between these states with cosine interpolation. These random modes can be used to give &quot;life&quot; to your presets - add some of that analog unpredictability... </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Attack causes the LFO to come on gradually from the start of the note. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rate sets the speed of the LFO, measured in milliseconds per cycle. Can be synced to tempo. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PHS controls the phase offset of the LFO. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PRE, or pre-delay, delays the start of the envelope from the start of the note. 0 means no delay. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ATT, or attack, controls how fast the envelope ramps up at start, measured in milliseconds. A value of 0 means instant. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>HOLD controls how long the envelope stays at peak after the attack phase. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>DEC, or decay, controls how fast the envelope falls off from its peak, measured in milliseconds it would take to go from peak to zero. The actual decay may be shorter if sustain is used. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SUS, or sustain, controls the sustain level of the envelope. The decay phase will not go below this level as long as the note is held. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>REL, or release, controls how long the release is for the note, measured in how long it would take to fall from peak to zero. Actual release may be shorter, depending on at what phase the note is released. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The slope knob controls the curve or shape of the envelope. A value of 0 creates straight rises and falls. Negative values create curves that start slowly, peak quickly and fall of slowly again. Positive values create curves that start and end quickly, and stay longer near the peaks. </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MultitapEchoControlDialog</name>
    <message>
        <source>Length</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Step length:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dry Gain:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lowpass stages:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Swap inputs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Swap left and right input channel for reflections</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>NesInstrument</name>
    <message>
        <source>Channel 1 Coarse detune</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Channel 1 Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Channel 1 Envelope length</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Channel 1 Duty cycle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Channel 1 Sweep amount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Channel 1 Sweep rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Channel 2 Coarse detune</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Channel 2 Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Channel 2 Envelope length</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Channel 2 Duty cycle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Channel 2 Sweep amount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Channel 2 Sweep rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Channel 3 Coarse detune</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Channel 3 Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Channel 4 Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Channel 4 Envelope length</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Channel 4 Noise frequency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Channel 4 Noise frequency sweep</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Master volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vibrato</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OscillatorObject</name>
    <message>
        <source>Osc %1 volume</source>
        <translation type="unfinished">حجم نوسان ساز %1</translation>
    </message>
    <message>
        <source>Osc %1 panning</source>
        <translation type="unfinished">تراز نوسان ساز %1</translation>
    </message>
    <message>
        <source>Osc %1 coarse detuning</source>
        <translation type="unfinished">کوک زمختی نوسان ساز %1</translation>
    </message>
    <message>
        <source>Osc %1 fine detuning left</source>
        <translation type="unfinished">کوک دقیق چپ نوسان ساز %1</translation>
    </message>
    <message>
        <source>Osc %1 fine detuning right</source>
        <translation type="unfinished">کوک دقیق راست نوسان ساز %1</translation>
    </message>
    <message>
        <source>Osc %1 phase-offset</source>
        <translation type="unfinished">انحراف فاز نوسان ساز %1</translation>
    </message>
    <message>
        <source>Osc %1 stereo phase-detuning</source>
        <translation type="unfinished">کوک فاز استریوی نوسان ساز %1</translation>
    </message>
    <message>
        <source>Osc %1 wave shape</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modulation type %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Osc %1 waveform</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Osc %1 harmonic</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PatmanView</name>
    <message>
        <source>Open other patch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here to open another patch-file. Loop and Tune settings are not reset.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Loop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Loop mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Here you can toggle the Loop mode. If enabled, PatMan will use the loop information available in the file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tune</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tune mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Here you can toggle the Tune mode. If enabled, PatMan will tune the sample to match the note&apos;s frequency.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No file selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open patch file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Patch-Files (*.pat)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PatternView</name>
    <message>
        <source>double-click to open this pattern in piano-roll
use mouse wheel to set velocity of a step</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open in piano-roll</source>
        <translation type="unfinished">در غلتک پیانو باز کن</translation>
    </message>
    <message>
        <source>Clear all notes</source>
        <translation type="unfinished">پاک کردن تمامی نت ها</translation>
    </message>
    <message>
        <source>Reset name</source>
        <translation type="unfinished">باز نشانی نام</translation>
    </message>
    <message>
        <source>Change name</source>
        <translation type="unfinished">تغییر نام</translation>
    </message>
    <message>
        <source>Add steps</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Remove steps</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PeakController</name>
    <message>
        <source>Peak Controller</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Peak Controller Bug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Due to a bug in older version of LMMS, the peak controllers may not be connect properly. Please ensure that peak controllers are connected properly and re-save this file. Sorry for any inconvenience caused.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PeakControllerDialog</name>
    <message>
        <source>PEAK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LFO Controller</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PeakControllerEffectControlDialog</name>
    <message>
        <source>BASE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Base amount:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modulation amount:</source>
        <translation type="unfinished">میزان مدولاسیون:</translation>
    </message>
    <message>
        <source>Attack:</source>
        <translation type="unfinished">تهاجم(Attack):</translation>
    </message>
    <message>
        <source>Release:</source>
        <translation type="unfinished">رهایی(Release):</translation>
    </message>
    <message>
        <source>AMNT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MULT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Amount Multiplicator:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ATCK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>DCAY</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>TRES</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Treshold:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PeakControllerEffectControls</name>
    <message>
        <source>Base value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modulation amount</source>
        <translation type="unfinished">مقدار مدولاسیون</translation>
    </message>
    <message>
        <source>Mute output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Attack</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Release</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Abs Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Amount Multiplicator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Treshold</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PianoRoll</name>
    <message>
        <source>Piano-Roll - %1</source>
        <translation>غلتک پیانو - %1</translation>
    </message>
    <message>
        <source>Piano-Roll - no pattern</source>
        <translation>غلتک پیانو - بدون الگو</translation>
    </message>
    <message>
        <source>Please open a pattern by double-clicking on it!</source>
        <translation>لطفا یک الگو را با دوبار کلیک روی أن باز کنید!</translation>
    </message>
    <message>
        <source>Last note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Note lock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Note Velocity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Note Panning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mark/unmark current semitone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mark current scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mark current chord</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unmark all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No scale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No chord</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Velocity: %1%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Panning: %1% left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Panning: %1% right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Panning: center</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please enter a new value between %1 and %2:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PianoRollWindow</name>
    <message>
        <source>Play/pause current pattern (Space)</source>
        <translation type="unfinished">پخش/مکث الگوی جاری (فاصله)</translation>
    </message>
    <message>
        <source>Record notes from MIDI-device/channel-piano</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Record notes from MIDI-device/channel-piano while playing song or BB track</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stop playing of current pattern (Space)</source>
        <translation type="unfinished">توقف پخش الگوی جاری (فاصله)</translation>
    </message>
    <message>
        <source>Click here to play the current pattern. This is useful while editing it. The pattern is automatically looped when its end is reached.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here to record notes from a MIDI-device or the virtual test-piano of the according channel-window to the current pattern. When recording all notes you play will be written to this pattern and you can play and edit them afterwards.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here to record notes from a MIDI-device or the virtual test-piano of the according channel-window to the current pattern. When recording all notes you play will be written to this pattern and you will hear the song or BB track in the background.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here to stop playback of current pattern.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Draw mode (Shift+D)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Erase mode (Shift+E)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select mode (Shift+S)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Detune mode (Shift+T)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here and draw mode will be activated. In this mode you can add, resize and move notes. This is the default mode which is used most of the time. You can also press &apos;Shift+D&apos; on your keyboard to activate this mode. In this mode, hold %1 to temporarily go into select mode.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here and erase mode will be activated. In this mode you can erase notes. You can also press &apos;Shift+E&apos; on your keyboard to activate this mode.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here and select mode will be activated. In this mode you can select notes. Alternatively, you can hold %1 in draw mode to temporarily use select mode.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here and detune mode will be activated. In this mode you can click a note to open its automation detuning. You can utilize this to slide notes from one to another. You can also press &apos;Shift+T&apos; on your keyboard to activate this mode.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cut selected notes (%1+X)</source>
        <translation type="unfinished">برش نت های انتخاب شده(Ctrl+X)</translation>
    </message>
    <message>
        <source>Copy selected notes (%1+C)</source>
        <translation type="unfinished">کپی نت های انتخاب شده(Ctrl+C)</translation>
    </message>
    <message>
        <source>Paste notes from clipboard (%1+V)</source>
        <translation type="unfinished">چسباندن نت ها از حافظه ی موقت(Ctrl+V)</translation>
    </message>
    <message>
        <source>Click here and the selected notes will be cut into the clipboard. You can paste them anywhere in any pattern by clicking on the paste button.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here and the selected notes will be copied into the clipboard. You can paste them anywhere in any pattern by clicking on the paste button.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here and the notes from the clipboard will be pasted at the first visible measure.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This controls the magnification of an axis. It can be helpful to choose magnification for a specific task. For ordinary editing, the magnification should be fitted to your smallest notes. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The &apos;Q&apos; stands for quantization, and controls the grid size notes and control points snap to. With smaller quantization values, you can draw shorter notes in Piano Roll, and more exact control points in the Automation Editor.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This lets you select the length of new notes. &apos;Last Note&apos; means that LMMS will use the note length of the note you last edited</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The feature is directly connected to the context-menu on the virtual keyboard, to the left in Piano Roll. After you have chosen the scale you want in this drop-down menu, you can right click on a desired key in the virtual keyboard, and then choose &apos;Mark current Scale&apos;. LMMS will highlight all notes that belongs to the chosen scale, and in the key you have selected!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Let you select a chord which LMMS then can draw or highlight.You can find the most common chords in this drop-down menu. After you have selected a chord, click anywhere to place the chord, and right click on the virtual keyboard to open context menu and highlight the chord. To return to single note placement, you need to choose &apos;No chord&apos; in this drop-down menu.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PianoView</name>
    <message>
        <source>Base note</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Plugin</name>
    <message>
        <source>Plugin not found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The plugin &quot;%1&quot; wasn&apos;t found or could not be loaded!
Reason: &quot;%2&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error while loading plugin</source>
        <translation type="unfinished">در بارگذاری اضافات اشتباه رخ داد</translation>
    </message>
    <message>
        <source>Failed to load plugin &quot;%1&quot;!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LMMS plugin %1 does not have a plugin descriptor named %2!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PluginBrowser</name>
    <message>
        <source>Instrument plugins</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Instrument browser</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Drag an instrument into either the Song-Editor, the Beat+Bassline Editor or into an existing instrument track.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ProjectNotes</name>
    <message>
        <source>Project notes</source>
        <translation type="unfinished">یادداشت های پروژه</translation>
    </message>
    <message>
        <source>Put down your project notes here.</source>
        <translation type="unfinished">یادداشت های پروژه ی خود  را اینجا قرار دهید.</translation>
    </message>
    <message>
        <source>Edit Actions</source>
        <translation type="unfinished">ویرایش کنش ها</translation>
    </message>
    <message>
        <source>&amp;Undo</source>
        <translation type="unfinished">&amp;واچینی</translation>
    </message>
    <message>
        <source>%1+Z</source>
        <translation type="unfinished">%1+Z</translation>
    </message>
    <message>
        <source>&amp;Redo</source>
        <translation type="unfinished">&amp;بازچینی</translation>
    </message>
    <message>
        <source>%1+Y</source>
        <translation type="unfinished">%1+Y</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation type="unfinished">&amp;کپی</translation>
    </message>
    <message>
        <source>%1+C</source>
        <translation type="unfinished">%1+C</translation>
    </message>
    <message>
        <source>Cu&amp;t</source>
        <translation type="unfinished">&amp;برش</translation>
    </message>
    <message>
        <source>%1+X</source>
        <translation type="unfinished">%1+X</translation>
    </message>
    <message>
        <source>&amp;Paste</source>
        <translation type="unfinished">&amp;چسباندن</translation>
    </message>
    <message>
        <source>%1+V</source>
        <translation type="unfinished">%1+V</translation>
    </message>
    <message>
        <source>Format Actions</source>
        <translation type="unfinished">قالب بندی کنش ها</translation>
    </message>
    <message>
        <source>&amp;Bold</source>
        <translation type="unfinished">&amp;برجسته</translation>
    </message>
    <message>
        <source>%1+B</source>
        <translation type="unfinished">%1+B</translation>
    </message>
    <message>
        <source>&amp;Italic</source>
        <translation type="unfinished">&amp;خوابیده</translation>
    </message>
    <message>
        <source>%1+I</source>
        <translation type="unfinished">%1+I</translation>
    </message>
    <message>
        <source>&amp;Underline</source>
        <translation type="unfinished">&amp;زیرخط</translation>
    </message>
    <message>
        <source>%1+U</source>
        <translation type="unfinished">%1+U</translation>
    </message>
    <message>
        <source>&amp;Left</source>
        <translation type="unfinished">&amp;چپ</translation>
    </message>
    <message>
        <source>%1+L</source>
        <translation type="unfinished">%1+L</translation>
    </message>
    <message>
        <source>C&amp;enter</source>
        <translation type="unfinished">&amp;مرکز</translation>
    </message>
    <message>
        <source>%1+E</source>
        <translation type="unfinished">%1+E</translation>
    </message>
    <message>
        <source>&amp;Right</source>
        <translation type="unfinished">&amp;راست</translation>
    </message>
    <message>
        <source>%1+R</source>
        <translation type="unfinished">%1+R</translation>
    </message>
    <message>
        <source>&amp;Justify</source>
        <translation type="unfinished">&amp;تراز</translation>
    </message>
    <message>
        <source>%1+J</source>
        <translation type="unfinished">%1+J</translation>
    </message>
    <message>
        <source>&amp;Color...</source>
        <translation type="unfinished">&amp;رنگ...</translation>
    </message>
</context>
<context>
    <name>ProjectRenderer</name>
    <message>
        <source>WAV-File (*.wav)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Compressed OGG-File (*.ogg)</source>
        <translation type="unfinished">پرونده ی OGG فشرده شده(*.ogg)</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>C</source>
        <comment>Note name</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Db</source>
        <comment>Note name</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>C#</source>
        <comment>Note name</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>D</source>
        <comment>Note name</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Eb</source>
        <comment>Note name</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>D#</source>
        <comment>Note name</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>E</source>
        <comment>Note name</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fb</source>
        <comment>Note name</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gb</source>
        <comment>Note name</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>F#</source>
        <comment>Note name</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>G</source>
        <comment>Note name</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ab</source>
        <comment>Note name</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>G#</source>
        <comment>Note name</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A</source>
        <comment>Note name</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bb</source>
        <comment>Note name</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A#</source>
        <comment>Note name</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>B</source>
        <comment>Note name</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QWidget</name>
    <message>
        <source>Name: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Maker: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Copyright: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Requires Real Time: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Yes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Real Time Capable: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>In Place Broken: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Channels In: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Channels Out: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File: %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RenameDialog</name>
    <message>
        <source>Rename...</source>
        <translation type="unfinished">تغییر نام...</translation>
    </message>
</context>
<context>
    <name>SampleBuffer</name>
    <message>
        <source>Open audio file</source>
        <translation type="unfinished">باز کردن پرونده ی صوتی</translation>
    </message>
    <message>
        <source>Wave-Files (*.wav)</source>
        <translation type="unfinished"> Wave- پرونده های(*.wav)</translation>
    </message>
    <message>
        <source>OGG-Files (*.ogg)</source>
        <translation type="unfinished">OGG-پرونده های (*.ogg)</translation>
    </message>
    <message>
        <source>DrumSynth-Files (*.ds)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FLAC-Files (*.flac)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SPEEX-Files (*.spx)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>VOC-Files (*.voc)</source>
        <translation type="unfinished">VOC-پرونده های (*.voc)</translation>
    </message>
    <message>
        <source>AIFF-Files (*.aif *.aiff)</source>
        <translation type="unfinished">AIFF-پرونده های (*.aif *.aiff)</translation>
    </message>
    <message>
        <source>AU-Files (*.au)</source>
        <translation type="unfinished">AU-پرونده های (*.au)</translation>
    </message>
    <message>
        <source>RAW-Files (*.raw)</source>
        <translation type="unfinished">RAW-پرونده های (*.raw)</translation>
    </message>
    <message>
        <source>All Audio-Files (*.wav *.ogg *.ds *.flac *.spx *.voc *.aif *.aiff *.au *.raw)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SampleTCOView</name>
    <message>
        <source>double-click to select sample</source>
        <translation type="unfinished">برای انتخاب نمونه دوبار کلیک کنید</translation>
    </message>
    <message>
        <source>Delete (middle mousebutton)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cut</source>
        <translation type="unfinished">برش</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="unfinished">کپی</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="unfinished">چسباندن</translation>
    </message>
    <message>
        <source>Mute/unmute (&lt;%1&gt; + middle click)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Set/clear record</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SampleTrack</name>
    <message>
        <source>Sample track</source>
        <translation type="unfinished">تراک نمونه</translation>
    </message>
    <message>
        <source>Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Panning</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SampleTrackView</name>
    <message>
        <source>Track volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Channel volume:</source>
        <translation type="unfinished">حجم کانال:</translation>
    </message>
    <message>
        <source>VOL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Panning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Panning:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PAN</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SetupDialog</name>
    <message>
        <source>Setup LMMS</source>
        <translation type="unfinished">برپایی LMMS</translation>
    </message>
    <message>
        <source>General settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>BUFFER SIZE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset to default-value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MISC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable tooltips</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show restart warning after changing settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Display volume as dBV </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Compress project files per default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>One instrument track window mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>HQ-mode for output audio-device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Compact track buttons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sync VST plugins to host playback</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable note labels in piano roll</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable waveform display by default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Keep effects running even without input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create backup file when saving a project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LANGUAGE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Paths</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LMMS working directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>VST-plugin directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Artwork directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Background artwork</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FL Studio installation directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LADSPA plugin paths</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>STK rawwave directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default Soundfont File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Performance settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>UI effects vs. performance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Smooth scroll in Song Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable auto save feature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show playback cursor in AudioFileProcessor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Audio settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>AUDIO INTERFACE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MIDI settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MIDI INTERFACE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished">لغو</translation>
    </message>
    <message>
        <source>Restart LMMS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please note that most changes won&apos;t take effect until you restart LMMS!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Frames: %1
Latency: %2 ms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Here you can setup the internal buffer-size used by LMMS. Smaller values result in a lower latency but also may cause unusable sound or bad performance, especially on older computers or systems with a non-realtime kernel.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose LMMS working directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose your VST-plugin directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose artwork-theme directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose FL Studio installation directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose LADSPA plugin directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose STK rawwave directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose default SoundFont</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose background artwork</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Here you can select your preferred audio-interface. Depending on the configuration of your system during compilation time you can choose between ALSA, JACK, OSS and more. Below you see a box which offers controls to setup the selected audio-interface.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Here you can select your preferred MIDI-interface. Depending on the configuration of your system during compilation time you can choose between ALSA, OSS and more. Below you see a box which offers controls to setup the selected MIDI-interface.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Song</name>
    <message>
        <source>Tempo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Master volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Master pitch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Project saved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The project %1 is now saved.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Project NOT saved.</source>
        <translation type="unfinished">پروژه ذخیره نشد.</translation>
    </message>
    <message>
        <source>The project %1 was not saved!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Import file</source>
        <translation type="unfinished">وارد کردن پرونده</translation>
    </message>
    <message>
        <source>MIDI sequences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FL Studio projects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hydrogen projects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>All file types</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Empty project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This project is empty so exporting makes no sense. Please put some items into Song Editor first!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select directory for writing exported tracks...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>untitled</source>
        <translation type="unfinished">بدون نام</translation>
    </message>
    <message>
        <source>Select file for project-export...</source>
        <translation type="unfinished">پرونده را برای استخراج پروژه مشخص کنید...</translation>
    </message>
    <message>
        <source>The following errors occured while loading: </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SongEditor</name>
    <message>
        <source>Could not open file</source>
        <translation>پرونده باز نشد</translation>
    </message>
    <message>
        <source>Could not write file</source>
        <translation>پرونده نوشته نشد</translation>
    </message>
    <message>
        <source>Could not open file %1. You probably have no permissions to read this file.
 Please make sure to have at least read permissions to the file and try again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error in file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The file %1 seems to contain errors and therefore can&apos;t be loaded.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tempo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>TEMPO/BPM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>tempo of song</source>
        <translation type="unfinished">گام ترانه(tempo)</translation>
    </message>
    <message>
        <source>The tempo of a song is specified in beats per minute (BPM). If you want to change the tempo of your song, change this value. Every measure has four beats, so the tempo in BPM specifies, how many measures / 4 should be played within a minute (or how many measures should be played within four minutes).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>High quality mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Master volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>master volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Master pitch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>master pitch</source>
        <translation type="unfinished">دانگ صدا(Pitch)</translation>
    </message>
    <message>
        <source>Value: %1%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Value: %1 semitones</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not open %1 for writing. You probably are not permitted to write to this file. Please make sure you have write-access to the file and try again.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SongEditorWindow</name>
    <message>
        <source>Song-Editor</source>
        <translation type="unfinished">ویرایشگر ترانه</translation>
    </message>
    <message>
        <source>Play song (Space)</source>
        <translation type="unfinished">پخش ترانه(فاصله)</translation>
    </message>
    <message>
        <source>Record samples from Audio-device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Record samples from Audio-device while playing song or BB track</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stop song (Space)</source>
        <translation type="unfinished">توقف ترانه (فاصله)</translation>
    </message>
    <message>
        <source>Add beat/bassline</source>
        <translation type="unfinished">اضافه ی خط بم/تپش (beat/baseline)</translation>
    </message>
    <message>
        <source>Add sample-track</source>
        <translation type="unfinished">اضافه ی باریکه ی نمونه</translation>
    </message>
    <message>
        <source>Add automation-track</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Draw mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit mode (select and move)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here, if you want to play your whole song. Playing will be started at the song-position-marker (green). You can also move it while playing.</source>
        <translation type="unfinished">اگر می خواهید تمام ترانه ی خود را پخش کنید اینجا را کلیک کنید.پخش از محل سازنده ی موقعیت شروع خواهد شد(سبز).همچنین می توانید در حال پخش آن را جابجا کنید.</translation>
    </message>
    <message>
        <source>Click here, if you want to stop playing of your song. The song-position-marker will be set to the start of your song.</source>
        <translation type="unfinished">اگر می خواهید پخش ترانه ی خود را متوقف کنید اینجا را کلیک کنید.سازنده موقعیت ترانه به شروع ترانه تنظیم خواهد شد.</translation>
    </message>
</context>
<context>
    <name>SpectrumAnalyzerControlDialog</name>
    <message>
        <source>Linear spectrum</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Linear Y axis</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SpectrumAnalyzerControls</name>
    <message>
        <source>Linear spectrum</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Linear Y axis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Channel mode</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TabWidget</name>
    <message>
        <source>Settings for %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TempoSyncKnob</name>
    <message>
        <source>Tempo Sync</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No Sync</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Eight beats</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Whole note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Half note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quarter note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>8th note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>16th note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>32nd note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Custom...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Custom </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Synced to Eight Beats</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Synced to Whole Note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Synced to Half Note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Synced to Quarter Note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Synced to 8th Note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Synced to 16th Note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Synced to 32nd Note</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TimeDisplayWidget</name>
    <message>
        <source>click to change time units</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TimeLineWidget</name>
    <message>
        <source>Enable/disable auto-scrolling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable/disable loop-points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>After stopping go back to begin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>After stopping go back to position at which playing was started</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>After stopping keep position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Press &lt;%1&gt; to disable magnetic loop points.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hold &lt;Shift&gt; to move the begin loop point; Press &lt;%1&gt; to disable magnetic loop points.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Track</name>
    <message>
        <source>Mute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Solo</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TrackContainer</name>
    <message>
        <source>Couldn&apos;t import file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Couldn&apos;t find a filter for importing file %1.
You should convert this file into a format supported by LMMS using another software.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Couldn&apos;t open file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Couldn&apos;t open file %1 for reading.
Please make sure you have read-permission to the file and the directory containing the file and try again!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Loading project...</source>
        <translation type="unfinished">بارگذاری پروژه...</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="unfinished">لغو</translation>
    </message>
    <message>
        <source>Please wait...</source>
        <translation type="unfinished">لطفا صبر کنید...</translation>
    </message>
    <message>
        <source>Importing MIDI-file...</source>
        <translation type="unfinished">وارد کردن پرونده ی MIDI...</translation>
    </message>
    <message>
        <source>Importing FLP-file...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TrackContentObject</name>
    <message>
        <source>Muted</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TrackContentObjectView</name>
    <message>
        <source>Current position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Press &lt;%1&gt; and drag to make a copy.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Current length</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Press &lt;%1&gt; for free resizing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1:%2 (%3:%4 to %5:%6)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete (middle mousebutton)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cut</source>
        <translation type="unfinished">برش</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation type="unfinished">کپی</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation type="unfinished">چسباندن</translation>
    </message>
    <message>
        <source>Mute/unmute (&lt;%1&gt; + middle click)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TrackOperationsWidget</name>
    <message>
        <source>Press &lt;%1&gt; while clicking on move-grip to begin a new drag&apos;n&apos;drop-action.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Actions for this track</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Solo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mute this track</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clone this track</source>
        <translation type="unfinished">تکثیر این تراک</translation>
    </message>
    <message>
        <source>Remove this track</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clear this track</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FX %1: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Turn all recording on</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Turn all recording off</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TripleOscillatorView</name>
    <message>
        <source>Use phase modulation for modulating oscillator 1 with oscillator 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use amplitude modulation for modulating oscillator 1 with oscillator 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mix output of oscillator 1 &amp; 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Synchronize oscillator 1 with oscillator 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use frequency modulation for modulating oscillator 1 with oscillator 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use phase modulation for modulating oscillator 2 with oscillator 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use amplitude modulation for modulating oscillator 2 with oscillator 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mix output of oscillator 2 &amp; 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Synchronize oscillator 2 with oscillator 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use frequency modulation for modulating oscillator 2 with oscillator 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Osc %1 volume:</source>
        <translation type="unfinished">حجم نوسان ساز %1:</translation>
    </message>
    <message>
        <source>With this knob you can set the volume of oscillator %1. When setting a value of 0 the oscillator is turned off. Otherwise you can hear the oscillator as loud as you set it here.</source>
        <translation type="unfinished">با این دستگیره می توانید حجم نوسان ساز  %1 را تنظیم کنید.هنگام تنظیم به ۰ ,نوسان ساز خاموش است.در غیر این صورت همان قدر که تنظیم کنید صدای نوسان سار را بلند خواهید شنید.</translation>
    </message>
    <message>
        <source>Osc %1 panning:</source>
        <translation type="unfinished">تراز نوسان ساز %1:</translation>
    </message>
    <message>
        <source>With this knob you can set the panning of the oscillator %1. A value of -100 means 100% left and a value of 100 moves oscillator-output right.</source>
        <translation type="unfinished">با این دستگیره می توانید تراز نوسان ساز %1 را تنظیم کنید.مقدار ۱۰۰- یعنی ۱۰۰٪ چپ و مقدار ۱۰۰ خروجی نوسان ساز را به راست منتقل می کند.</translation>
    </message>
    <message>
        <source>Osc %1 coarse detuning:</source>
        <translation type="unfinished">کوک زمختی نوسان ساز %1:</translation>
    </message>
    <message>
        <source>semitones</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>With this knob you can set the coarse detuning of oscillator %1. You can detune the oscillator 24 semitones (2 octaves) up and down. This is useful for creating sounds with a chord.</source>
        <translation type="unfinished">با این دستگیره می توانید کوک زمختی نوسان ساز %1 را تنظیم کنید.شما می توانید کوک نوسان ساز را در ۱۲ نیم صدا (۱ نت) بالا یا پایین کنید. این برای ایجاد صدا به همراه زه (Chord) مفید خواهد بود.</translation>
    </message>
    <message>
        <source>Osc %1 fine detuning left:</source>
        <translation type="unfinished">کوک دقیق چپ نوسان ساز %1:</translation>
    </message>
    <message>
        <source>cents</source>
        <translation type="unfinished">درصد</translation>
    </message>
    <message>
        <source>With this knob you can set the fine detuning of oscillator %1 for the left channel. The fine-detuning is ranged between -100 cents and +100 cents. This is useful for creating &quot;fat&quot; sounds.</source>
        <translation type="unfinished">با این دستگیره می توانید کانال چپ نوسان ساز %1 را کوک دقیق کنید.کوک دقیق بین ۱۰۰- در صد و ۱۰۰ در صد محدود شده است.این برای ایجاد صدا های چاق (fat) مفید است.</translation>
    </message>
    <message>
        <source>Osc %1 fine detuning right:</source>
        <translation type="unfinished">کوک دقیق راست نوسان ساز %1:</translation>
    </message>
    <message>
        <source>With this knob you can set the fine detuning of oscillator %1 for the right channel. The fine-detuning is ranged between -100 cents and +100 cents. This is useful for creating &quot;fat&quot; sounds.</source>
        <translation type="unfinished">با این دستگیره می توانید کانال راست نوسان ساز %1 را کوک دقیق کنید.کوک دقیق بین ۱۰۰- در صد و ۱۰۰ در صد محدود شده است.این برای ایجاد صدا های چاق (fat) مفید است.</translation>
    </message>
    <message>
        <source>Osc %1 phase-offset:</source>
        <translation type="unfinished">انحراف فاز نوسان ساز %1:</translation>
    </message>
    <message>
        <source>degrees</source>
        <translation type="unfinished">درجه ها</translation>
    </message>
    <message>
        <source>With this knob you can set the phase-offset of oscillator %1. That means you can move the point within an oscillation where the oscillator begins to oscillate. For example if you have a sine-wave and have a phase-offset of 180 degrees the wave will first go down. It&apos;s the same with a square-wave.</source>
        <translation type="unfinished">با این دستگیره می توانید انحراف فاز نوسان ساز %1 را تنظیم کنید.این یعنی اینکه شما می توانید نقطه ی شروع نوسان نوسان ساز را جابجا کنید.برای مثال اگر یک موج سینوسی و انحراف فاز ۱۸۰ داشته باشید, موج در ابتدا به پایین می رود.برای موج مربعی نیز شبیه همین است.</translation>
    </message>
    <message>
        <source>Osc %1 stereo phase-detuning:</source>
        <translation type="unfinished">کوک فاز استریوی نوسان ساز %1:</translation>
    </message>
    <message>
        <source>With this knob you can set the stereo phase-detuning of oscillator %1. The stereo phase-detuning specifies the size of the difference between the phase-offset of left and right channel. This is very good for creating wide stereo sounds.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use a sine-wave for current oscillator.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use a triangle-wave for current oscillator.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use a saw-wave for current oscillator.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use a square-wave for current oscillator.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use a moog-like saw-wave for current oscillator.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use an exponential wave for current oscillator.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use white-noise for current oscillator.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use a user-defined waveform for current oscillator.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VersionedSaveDialog</name>
    <message>
        <source>Increment version number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Decrement version number</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VestigeInstrumentView</name>
    <message>
        <source>Open other VST-plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here, if you want to open another VST-plugin. After clicking on this button, a file-open-dialog appears and you can select your file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show/hide GUI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here to show or hide the graphical user interface (GUI) of your VST-plugin.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Turn off all notes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open VST-plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>DLL-files (*.dll)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>EXE-files (*.exe)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No VST-plugin loaded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Control VST-plugin from LMMS host</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here, if you want to control VST-plugin from host.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open VST-plugin preset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here, if you want to open another *.fxp, *.fxb VST-plugin preset.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Previous (-)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here, if you want to switch to another VST-plugin preset program.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save preset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here, if you want to save current VST-plugin preset program.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Next (+)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here to select presets that are currently loaded in VST.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>by </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> - VST plugin control</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VisualizationWidget</name>
    <message>
        <source>click to enable/disable visualization of master-output</source>
        <translation type="unfinished">برای فعال / غیرفعال کردن تصور خروجی اصلی کلیک کنید</translation>
    </message>
    <message>
        <source>Click to enable</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VstEffectControlDialog</name>
    <message>
        <source>Show/hide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Control VST-plugin from LMMS host</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here, if you want to control VST-plugin from host.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open VST-plugin preset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here, if you want to open another *.fxp, *.fxb VST-plugin preset.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Previous (-)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here, if you want to switch to another VST-plugin preset program.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Next (+)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here to select presets that are currently loaded in VST.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save preset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here, if you want to save current VST-plugin preset program.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Effect by: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&amp;nbsp;&lt;br /&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VstPlugin</name>
    <message>
        <source>Loading plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open Preset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vst Plugin Preset (*.fxp *.fxb)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>: default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save Preset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>.fxp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>.FXP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>.FXB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>.fxb</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please wait while loading VST plugin...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The VST plugin %1 could not be loaded.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WatsynInstrument</name>
    <message>
        <source>Volume A1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volume A2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volume B1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volume B2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Panning A1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Panning A2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Panning B1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Panning B2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Freq. multiplier A1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Freq. multiplier A2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Freq. multiplier B1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Freq. multiplier B2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Left detune A1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Left detune A2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Left detune B1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Left detune B2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Right detune A1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Right detune A2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Right detune B1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Right detune B2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A-B Mix</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A-B Mix envelope amount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A-B Mix envelope attack</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A-B Mix envelope hold</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A-B Mix envelope decay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A1-B2 Crosstalk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A2-A1 modulation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>B2-B1 modulation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Selected graph</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WatsynView</name>
    <message>
        <source>Select oscillator A1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select oscillator A2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select oscillator B1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select oscillator B2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mix output of A2 to A1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modulate amplitude of A1 with output of A2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ring-modulate A1 and A2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modulate phase of A1 with output of A2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Mix output of B2 to B1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modulate amplitude of B1 with output of B2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ring-modulate B1 and B2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modulate phase of B1 with output of B2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Draw your own waveform here by dragging your mouse on this graph.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Load waveform</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click to load a waveform from a sample file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Phase left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click to shift phase by -15 degrees</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Phase right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click to shift phase by +15 degrees</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Normalize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click to normalize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Invert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click to invert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Smooth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click to smooth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sine wave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click for sine wave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Triangle wave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click for triangle wave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click for saw wave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Square wave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click for square wave</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ZynAddSubFxInstrument</name>
    <message>
        <source>Portamento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Filter Frequency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Filter Resonance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bandwidth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FM Gain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Resonance Center Frequency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Resonance Bandwidth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Forward MIDI Control Change Events</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ZynAddSubFxView</name>
    <message>
        <source>Show GUI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here to show or hide the graphical user interface (GUI) of ZynAddSubFX.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Portamento:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PORT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Filter Frequency:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FREQ</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Filter Resonance:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>RES</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bandwidth:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>BW</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FM Gain:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FM GAIN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Resonance center frequency:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>RES CF</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Resonance bandwidth:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>RES BW</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Forward MIDI Control Changes</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>audioFileProcessor</name>
    <message>
        <source>Amplify</source>
        <translation>تقویت</translation>
    </message>
    <message>
        <source>Start of sample</source>
        <translation>شروع نمونه</translation>
    </message>
    <message>
        <source>End of sample</source>
        <translation>پایان نمونه</translation>
    </message>
    <message>
        <source>Reverse sample</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stutter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Loopback point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Loop mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Interpolation mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Linear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sinc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sample not found: %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>bitInvader</name>
    <message>
        <source>Samplelength</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>bitInvaderView</name>
    <message>
        <source>Sample Length</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sine wave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Triangle wave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Saw wave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Square wave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>White noise wave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User defined wave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Smooth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here to smooth waveform.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Interpolation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Normalize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Draw your own waveform here by dragging your mouse on this graph.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click for a sine-wave.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here for a triangle-wave.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here for a saw-wave.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here for a square-wave.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here for white-noise.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here for a user-defined shape.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dynProcControlDialog</name>
    <message>
        <source>INPUT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input gain:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OUTPUT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output gain:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ATTACK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Peak attack time:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>RELEASE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Peak release time:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset waveform</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here to reset the wavegraph back to default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Smooth waveform</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here to apply smoothing to wavegraph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Increase wavegraph amplitude by 1dB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here to increase wavegraph amplitude by 1dB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Decrease wavegraph amplitude by 1dB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here to decrease wavegraph amplitude by 1dB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stereomode Maximum</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Process based on the maximum of both stereo channels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stereomode Average</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Process based on the average of both stereo channels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stereomode Unlinked</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Process each stereo channel independently</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>dynProcControls</name>
    <message>
        <source>Input gain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output gain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Attack time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Release time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stereo mode</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>graphModel</name>
    <message>
        <source>Graph</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>kickerInstrument</name>
    <message>
        <source>Start frequency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>End frequency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Length</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Distortion Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Distortion End</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Envelope Slope</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Noise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Frequency Slope</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start from note</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>End to note</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>kickerInstrumentView</name>
    <message>
        <source>Start frequency:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>End frequency:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gain:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Frequency Slope:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Envelope Length:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Envelope Slope:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Noise:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Distortion Start:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Distortion End:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ladspaBrowserView</name>
    <message>
        <source>Available Effects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unavailable Effects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Instruments</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Analysis Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Don&apos;t know</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This dialog displays information on all of the LADSPA plugins LMMS was able to locate. The plugins are divided into five categories based upon an interpretation of the port types and names.

Available Effects are those that can be used by LMMS. In order for LMMS to be able to use an effect, it must, first and foremost, be an effect, which is to say, it has to have both input channels and output channels. LMMS identifies an input channel as an audio rate port containing &apos;in&apos; in the name. Output channels are identified by the letters &apos;out&apos;. Furthermore, the effect must have the same number of inputs and outputs and be real time capable.

Unavailable Effects are those that were identified as effects, but either didn&apos;t have the same number of input and output channels or weren&apos;t real time capable.

Instruments are plugins for which only output channels were identified.

Analysis Tools are plugins for which only input channels were identified.

Don&apos;t Knows are plugins for which no input or output channels were identified.

Double clicking any of the plugins will bring up information on the ports.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type:</source>
        <translation type="unfinished">نوع:</translation>
    </message>
</context>
<context>
    <name>ladspaDescription</name>
    <message>
        <source>Plugins</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ladspaPortDialog</name>
    <message>
        <source>Ports</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Direction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Min &lt; Default &lt; Max</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Logarithmic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SR Dependent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Control</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Toggled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Integer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Float</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Yes</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>lb302Synth</name>
    <message>
        <source>VCF Cutoff Frequency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>VCF Resonance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>VCF Envelope Mod</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>VCF Envelope Decay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Distortion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Waveform</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Slide Decay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Slide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Accent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dead</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>24dB/oct Filter</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>lb302SynthView</name>
    <message>
        <source>Cutoff Freq:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Resonance:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Env Mod:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Decay:</source>
        <translation type="unfinished">محو شدن(Decay):</translation>
    </message>
    <message>
        <source>303-es-que, 24dB/octave, 3 pole filter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Slide Decay:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>DIST:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Saw wave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here for a saw-wave.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Triangle wave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here for a triangle-wave.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Square wave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here for a square-wave.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Rounded square wave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here for a square-wave with a rounded end.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Moog wave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here for a moog-like wave.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sine wave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click for a sine-wave.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>White noise wave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here for an exponential wave.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here for white-noise.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bandlimited saw wave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here for bandlimited saw wave.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bandlimited square wave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here for bandlimited square wave.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bandlimited triangle wave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here for bandlimited triangle wave.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bandlimited moog saw wave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here for bandlimited moog saw wave.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>lb303Synth</name>
    <message>
        <source>VCF Cutoff Frequency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>VCF Resonance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>VCF Envelope Mod</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>VCF Envelope Decay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Distortion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Waveform</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Slide Decay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Slide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Accent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dead</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>24dB/oct Filter</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>lb303SynthView</name>
    <message>
        <source>Cutoff Freq:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>CUT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Resonance:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>RES</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Env Mod:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ENV MOD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Decay:</source>
        <translation type="unfinished">محو شدن(Decay):</translation>
    </message>
    <message>
        <source>DEC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>303-es-que, 24dB/octave, 3 pole filter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Slide Decay:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SLIDE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>DIST:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>DIST</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>WAVE:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>WAVE</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>malletsInstrument</name>
    <message>
        <source>Hardness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vibrato Gain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vibrato Freq</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stick Mix</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modulator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Crossfade</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LFO Speed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LFO Depth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ADSR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pressure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Motion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Speed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bowed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Spread</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Marimba</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vibraphone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Agogo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wood1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reso</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wood2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Beats</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Two Fixed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clump</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tubular Bells</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Uniform Bar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tuned Bar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Glass</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tibetan Bowl</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Missing files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Your Stk-installation seems to be incomplete. Please make sure the full Stk-package is installed!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>malletsInstrumentView</name>
    <message>
        <source>Instrument</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Spread</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Spread:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hardness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hardness:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Position:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vib Gain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vib Gain:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vib Freq</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vib Freq:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stick Mix</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stick Mix:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modulator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modulator:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Crossfade</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Crossfade:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LFO Speed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LFO Speed:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LFO Depth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LFO Depth:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ADSR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ADSR:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bowed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pressure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pressure:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Motion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Motion:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Speed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Speed:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vibrato</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vibrato:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>manageVSTEffectView</name>
    <message>
        <source> - VST parameter control</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>VST Sync</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here if you want to synchronize all parameters with VST plugin.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Automated</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here if you want to display automated parameters only.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>    Close    </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close VST effect knob-controller window.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>manageVestigeInstrumentView</name>
    <message>
        <source> - VST plugin control</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>VST Sync</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here if you want to synchronize all parameters with VST plugin.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Automated</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here if you want to display automated parameters only.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>    Close    </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Close VST plugin knob-controller window.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>opl2instrument</name>
    <message>
        <source>Patch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Op 1 Attack</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Op 1 Decay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Op 1 Sustain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Op 1 Release</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Op 1 Level</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Op 1 Level Scaling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Op 1 Frequency Multiple</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Op 1 Feedback</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Op 1 Key Scaling Rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Op 1 Percussive Envelope</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Op 1 Tremolo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Op 1 Vibrato</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Op 1 Waveform</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Op 2 Attack</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Op 2 Decay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Op 2 Sustain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Op 2 Release</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Op 2 Level</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Op 2 Level Scaling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Op 2 Frequency Multiple</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Op 2 Key Scaling Rate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Op 2 Percussive Envelope</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Op 2 Tremolo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Op 2 Vibrato</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Op 2 Waveform</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>FM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vibrato Depth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tremolo Depth</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>organicInstrument</name>
    <message>
        <source>Distortion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volume</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>organicInstrumentView</name>
    <message>
        <source>Distortion:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volume:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Randomise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Osc %1 waveform:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Osc %1 volume:</source>
        <translation type="unfinished">حجم نوسان ساز %1:</translation>
    </message>
    <message>
        <source>Osc %1 panning:</source>
        <translation type="unfinished">تراز نوسان ساز %1:</translation>
    </message>
    <message>
        <source>cents</source>
        <translation type="unfinished">درصد</translation>
    </message>
    <message>
        <source>The distortion knob adds distortion to the output of the instrument. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The volume knob controls the volume of the output of the instrument. It is cumulative with the instrument window&apos;s volume control. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The randomize button randomizes all knobs except the harmonics,main volume and distortion knobs. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Osc %1 stereo detuning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Osc %1 harmonic:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>papuInstrument</name>
    <message>
        <source>Sweep time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sweep direction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sweep RtShift amount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wave Pattern Duty</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Channel 1 volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volume sweep direction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Length of each step in sweep</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Channel 2 volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Channel 3 volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Channel 4 volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Right Output level</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Left Output level</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Channel 1 to SO2 (Left)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Channel 2 to SO2 (Left)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Channel 3 to SO2 (Left)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Channel 4 to SO2 (Left)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Channel 1 to SO1 (Right)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Channel 2 to SO1 (Right)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Channel 3 to SO1 (Right)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Channel 4 to SO1 (Right)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Treble</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bass</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shift Register width</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>papuInstrumentView</name>
    <message>
        <source>Sweep Time:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sweep Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sweep RtShift amount:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sweep RtShift amount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wave pattern duty:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wave Pattern Duty</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Square Channel 1 Volume:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Length of each step in sweep:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Length of each step in sweep</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wave pattern duty</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Square Channel 2 Volume:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Square Channel 2 Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wave Channel Volume:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wave Channel Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Noise Channel Volume:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Noise Channel Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SO1 Volume (Right):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SO1 Volume (Right)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SO2 Volume (Left):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SO2 Volume (Left)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Treble:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Treble</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bass:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bass</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sweep Direction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volume Sweep Direction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shift Register Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Channel1 to SO1 (Right)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Channel2 to SO1 (Right)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Channel3 to SO1 (Right)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Channel4 to SO1 (Right)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Channel1 to SO2 (Left)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Channel2 to SO2 (Left)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Channel3 to SO2 (Left)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Channel4 to SO2 (Left)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Wave Pattern</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The amount of increase or decrease in frequency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The rate at which increase or decrease in frequency occurs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The duty cycle is the ratio of the duration (time) that a signal is ON versus the total period of the signal.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Square Channel 1 Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The delay between step change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Draw the wave here</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>pluginBrowser</name>
    <message>
        <source>no description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Incomplete monophonic imitation tb303</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Plugin for freely manipulating stereo output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Plugin for controlling knobs with sound peaks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Plugin for enhancing stereo separation of a stereo input file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>List installed LADSPA plugins</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Filter for importing FL Studio projects into LMMS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>GUS-compatible patch instrument</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Additive Synthesizer for organ-like sounds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Tuneful things to bang on</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>VST-host for using VST(i)-plugins within LMMS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vibrating string modeler</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>plugin for using arbitrary LADSPA-effects inside LMMS.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Filter for importing MIDI-files into LMMS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Emulation of the MOS6581 and MOS8580 SID.
This chip was used in the Commodore 64 computer.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Player for SoundFont files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Emulation of GameBoy (TM) APU</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Customizable wavetable synthesizer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Embedded ZynAddSubFX</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>2-operator FM Synth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Filter for importing Hydrogen files into LMMS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>LMMS port of sfxr</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Monstrous 3-oscillator synth with modulation matrix</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Three powerful oscillators you can modulate in several ways</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A native amplifier plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Carla Rack Instrument</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>4-oscillator modulatable wavetable synth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>plugin for waveshaping</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Boost your bass the fast and simple way</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Versatile drum synthesizer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Simple sampler with various settings for using samples (e.g. drums) in an instrument-track</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>plugin for processing dynamics in a flexible way</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Carla Patchbay Instrument</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>plugin for using arbitrary VST effects inside LMMS.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Graphical spectrum analyzer plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A NES-like synthesizer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Player for GIG files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A multitap echo delay plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A native flanger plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A native delay plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>An oversampling bitcrusher</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A native eq plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A 4-band Crossover Equalizer</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>setupWidget</name>
    <message>
        <source>JACK (JACK Audio Connection Kit)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OSS Raw-MIDI (Open Sound System)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SDL (Simple DirectMedia Layer)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PulseAudio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dummy (no MIDI support)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ALSA Raw-MIDI (Advanced Linux Sound Architecture)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>PortAudio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dummy (no sound output)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ALSA (Advanced Linux Sound Architecture)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OSS (Open Sound System)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>WinMM MIDI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ALSA-Sequencer (Advanced Linux Sound Architecture)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>sf2Instrument</name>
    <message>
        <source>Bank</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Patch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reverb</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reverb Roomsize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reverb Damping</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reverb Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reverb Level</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Chorus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Chorus Lines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Chorus Level</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Chorus Speed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Chorus Depth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>A soundfont %1 could not be loaded.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>sf2InstrumentView</name>
    <message>
        <source>Open other SoundFont file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here to open another SF2 file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose the patch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Gain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Apply reverb (if supported)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This button enables the reverb effect. This is useful for cool effects, but only works on files that support it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reverb Roomsize:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reverb Damping:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reverb Width:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reverb Level:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Apply chorus (if supported)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>This button enables the chorus effect. This is useful for cool echo effects, but only works on files that support it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Chorus Lines:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Chorus Level:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Chorus Speed:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Chorus Depth:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open SoundFont file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SoundFont2 Files (*.sf2)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>sfxrInstrument</name>
    <message>
        <source>Wave Form</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>sidInstrument</name>
    <message>
        <source>Cutoff</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Resonance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Filter type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Voice 3 off</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Chip model</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>sidInstrumentView</name>
    <message>
        <source>Volume:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Resonance:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cutoff frequency:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>High-Pass filter </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Band-Pass filter </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Low-Pass filter </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Voice3 Off </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MOS6581 SID </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MOS8580 SID </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Attack:</source>
        <translation type="unfinished">تهاجم(Attack):</translation>
    </message>
    <message>
        <source>Attack rate determines how rapidly the output of Voice %1 rises from zero to peak amplitude.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Decay:</source>
        <translation type="unfinished">محو شدن(Decay):</translation>
    </message>
    <message>
        <source>Decay rate determines how rapidly the output falls from the peak amplitude to the selected Sustain level.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sustain:</source>
        <translation type="unfinished">تقویت(Sustain):</translation>
    </message>
    <message>
        <source>Output of Voice %1 will remain at the selected Sustain amplitude as long as the note is held.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Release:</source>
        <translation type="unfinished">رهایی(Release):</translation>
    </message>
    <message>
        <source>The output of of Voice %1 will fall from Sustain amplitude to zero amplitude at the selected Release rate.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pulse Width:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The Pulse Width resolution allows the width to be smoothly swept with no discernable stepping. The Pulse waveform on Oscillator %1 must be selected to have any audible effect.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Coarse:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The Coarse detuning allows to detune Voice %1 one octave up or down.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pulse Wave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Triangle Wave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>SawTooth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Noise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sync</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sync synchronizes the fundamental frequency of Oscillator %1 with the fundamental frequency of Oscillator %2 producing &quot;Hard Sync&quot; effects.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ring-Mod</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ring-mod replaces the Triangle Waveform output of Oscillator %1 with a &quot;Ring Modulated&quot; combination of Oscillators %1 and %2.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Filtered</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>When Filtered is on, Voice %1 will be processed through the Filter. When Filtered is off, Voice %1 appears directly at the output, and the Filter has no effect on it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Test</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Test, when set, resets and locks Oscillator %1 at zero until Test is turned off.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>stereoEnhancerControlDialog</name>
    <message>
        <source>WIDE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Width:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>stereoEnhancerControls</name>
    <message>
        <source>Width</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>stereoMatrixControlDialog</name>
    <message>
        <source>Left to Left Vol:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Left to Right Vol:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Right to Left Vol:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Right to Right Vol:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>stereoMatrixControls</name>
    <message>
        <source>Left to Left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Left to Right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Right to Left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Right to Right</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>vestigeInstrument</name>
    <message>
        <source>Loading plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please wait while loading VST-plugin...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>vibed</name>
    <message>
        <source>String %1 volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>String %1 stiffness</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pick %1 position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pickup %1 position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pan %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Detune %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fuzziness %1 </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Length %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Impulse %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Octave %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>vibedView</name>
    <message>
        <source>Volume:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The &apos;V&apos; knob sets the volume of the selected string.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>String stiffness:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The &apos;S&apos; knob sets the stiffness of the selected string.  The stiffness of the string affects how long the string will ring out.  The lower the setting, the longer the string will ring.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pick position:</source>
        <translation type="unfinished">برگزیدن موقعیت:</translation>
    </message>
    <message>
        <source>The &apos;P&apos; knob sets the position where the selected string will be &apos;picked&apos;.  The lower the setting the closer the pick is to the bridge.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pickup position:</source>
        <translation type="unfinished">برداشتن موقعیت:</translation>
    </message>
    <message>
        <source>The &apos;PU&apos; knob sets the position where the vibrations will be monitored for the selected string.  The lower the setting, the closer the pickup is to the bridge.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pan:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The Pan knob determines the location of the selected string in the stereo field.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Detune:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The Detune knob modifies the pitch of the selected string.  Settings less than zero will cause the string to sound flat.  Settings greater than zero will cause the string to sound sharp.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Fuzziness:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The Slap knob adds a bit of fuzz to the selected string which is most apparent during the attack, though it can also be used to make the string sound more &apos;metallic&apos;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Length:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The Length knob sets the length of the selected string.  Longer strings will both ring longer and sound brighter, however, they will also eat up more CPU cycles.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Impulse or initial state</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The &apos;Imp&apos; selector determines whether the waveform in the graph is to be treated as an impulse imparted to the string by the pick or the initial state of the string.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Octave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The Octave selector is used to choose which harmonic of the note the string will ring at.  For example, &apos;-2&apos; means the string will ring two octaves below the fundamental, &apos;F&apos; means the string will ring at the fundamental, and &apos;6&apos; means the string will ring six octaves above the fundamental.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Impulse Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The waveform editor provides control over the initial state or impulse that is used to start the string vibrating.  The buttons to the right of the graph will initialize the waveform to the selected type.  The &apos;?&apos; button will load a waveform from a file--only the first 128 samples will be loaded.

The waveform can also be drawn in the graph.

The &apos;S&apos; button will smooth the waveform.

The &apos;N&apos; button will normalize the waveform.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Vibed models up to nine independently vibrating strings.  The &apos;String&apos; selector allows you to choose which string is being edited.  The &apos;Imp&apos; selector chooses whether the graph represents an impulse or the initial state of the string.  The &apos;Octave&apos; selector chooses which harmonic the string should vibrate at.

The graph allows you to control the initial state or impulse used to set the string in motion.

The &apos;V&apos; knob controls the volume.  The &apos;S&apos; knob controls the string&apos;s stiffness.  The &apos;P&apos; knob controls the pick position.  The &apos;PU&apos; knob controls the pickup position.

&apos;Pan&apos; and &apos;Detune&apos; hopefully don&apos;t need explanation.  The &apos;Slap&apos; knob adds a bit of fuzz to the sound of the string.

The &apos;Length&apos; knob controls the length of the string.

The LED in the lower right corner of the waveform editor determines whether the string is active in the current instrument.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable waveform</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here to enable/disable waveform.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>String</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The String selector is used to choose which string the controls are editing.  A Vibed instrument can contain up to nine independently vibrating strings.  The LED in the lower right corner of the waveform editor indicates whether the selected string is active.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sine wave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Triangle wave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Saw wave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Square wave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>White noise wave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>User defined wave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Smooth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here to smooth waveform.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Normalize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here to normalize waveform.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use a sine-wave for current oscillator.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use a triangle-wave for current oscillator.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use a saw-wave for current oscillator.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use a square-wave for current oscillator.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use white-noise for current oscillator.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use a user-defined waveform for current oscillator.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>voiceObject</name>
    <message>
        <source>Voice %1 pulse width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Voice %1 attack</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Voice %1 decay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Voice %1 sustain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Voice %1 release</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Voice %1 coarse detuning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Voice %1 wave shape</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Voice %1 sync</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Voice %1 ring modulate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Voice %1 filtered</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Voice %1 test</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>waveShaperControlDialog</name>
    <message>
        <source>INPUT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Input gain:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OUTPUT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output gain:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reset waveform</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here to reset the wavegraph back to default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Smooth waveform</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here to apply smoothing to wavegraph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Increase graph amplitude by 1dB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here to increase wavegraph amplitude by 1dB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Decrease graph amplitude by 1dB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Click here to decrease wavegraph amplitude by 1dB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clip input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clip input signal to 0dB</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>waveShaperControls</name>
    <message>
        <source>Input gain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Output gain</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
